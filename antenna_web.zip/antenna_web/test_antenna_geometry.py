import requests
import json
import numpy as np


BASE_URL = "http://localhost:5000/api/antenna/create"


def test_dipole():
    print("\nTesting Dipole Geometry...")
    data = {
        "type": "dipole",
        "frequency": 300e6,
        "length": 0.5,
        "radius": 0.005,
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code != 200:
        print(f"Failed: {response.text}")
        return

    result = response.json()
    if not result.get("success"):
        print(f"Error: {result.get('error')}")
        return

    geometries = result["data"]["geometries"]
    total_length = 0.0
    for geom in geometries:
        if geom["type"] == "wire":
            start = np.array(geom["start"])
            end = np.array(geom["end"])
            total_length += np.linalg.norm(end - start)

    print(f"Total Wire Length: {total_length:.4f} m (Expected: 0.5000 m)")
    if abs(total_length - 0.5) < 1e-4:
        print("PASS: Dipole Geometry Verified")
    else:
        print("FAIL: Dipole Geometry Mismatch")


def test_yagi():
    print("\nTesting Yagi Geometry...")
    data = {
        "type": "yagi",
        "frequency": 300e6,
        "num_directors": 3,
        "radius": 0.001,
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code != 200:
        print(f"Failed: {response.text}")
        return

    result = response.json()
    if not result.get("success"):
        print(f"Yagi Error: {result.get('error')}")
        return

    geoms = result["data"]["geometries"]
    count = len(geoms)
    print(f"Number of geometries: {count}")
    if count in [6, 7]:
        print("PASS: Yagi Elements Count Verified (Approx)")
    else:
        print("FAIL: Yagi Elements Count Mismatch")


def test_helix():
    print("\nTesting Helix Geometry...")
    data = {
        "type": "helix",
        "frequency": 300e6,
        "turns": 5,
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code != 200:
        print(f"Failed: {response.text}")
        return

    result = response.json()
    if not result.get("success"):
        print(f"Helix Error: {result.get('error')}")
        return

    geoms = result["data"]["geometries"]
    helix_geoms = [g for g in geoms if g["type"] == "helix"]
    if not helix_geoms:
        print("FAIL: No helix geometry found")
        return

    points = helix_geoms[0]["points"]
    print(f"Number of points: {len(points)} (Expected: 200)")
    if len(points) == 200:
        print("PASS: Helix Points Verified")
    else:
        print("FAIL: Helix Points Mismatch")


def test_monopole_ground():
    print("\nTesting Monopole Ground Plane...")
    data = {
        "type": "monopole",
        "frequency": 300e6,
        "length": 0.25,
        "radius": 0.005,
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code != 200:
        print(f"Failed: {response.text}")
        return

    result = response.json()
    if not result.get("success"):
        print(f"Monopole Error: {result.get('error')}")
        return

    geoms = result["data"]["geometries"]
    wire_count = sum(1 for g in geoms if g["type"] == "wire")
    rect_count = sum(1 for g in geoms if g["type"] == "rectangle")
    print(f"Wire count: {wire_count}, Rectangle count: {rect_count}")
    if wire_count >= 1 and rect_count >= 1:
        print("PASS: Monopole Ground Plane Present")
    else:
        print("FAIL: Monopole Ground Plane Missing")


def test_patch_geometry():
    print("\nTesting Patch Geometry...")
    data = {
        "type": "patch",
        "frequency": 2.4e9,
        "substrate_er": 4.4,
        "substrate_h": 1.6e-3,
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code != 200:
        print(f"Failed: {response.text}")
        return

    result = response.json()
    if not result.get("success"):
        print(f"Patch Error: {result.get('error')}")
        return

    geoms = result["data"]["geometries"]
    wire_count = sum(1 for g in geoms if g["type"] == "wire")
    rect_count = sum(1 for g in geoms if g["type"] == "rectangle")
    print(f"Wire count: {wire_count}, Rectangle count: {rect_count}")
    if wire_count >= 1 and rect_count >= 2:
        print("PASS: Patch Geometry Verified (patch, ground and feed)")
    else:
        print("FAIL: Patch Geometry Mismatch")


def test_horn_geometry():
    print("\nTesting Horn Geometry...")
    data = {
        "type": "horn",
        "frequency": 10e9,
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code != 200:
        print(f"Failed: {response.text}")
        return

    result = response.json()
    if not result.get("success"):
        print(f"Horn Error: {result.get('error')}")
        return

    geoms = result["data"]["geometries"]
    horn_count = sum(1 for g in geoms if g["type"] == "horn")
    wire_count = sum(1 for g in geoms if g["type"] == "wire")
    print(f"Horn count: {horn_count}, Wire count: {wire_count}")
    if horn_count >= 1 and wire_count >= 1:
        print("PASS: Horn Geometry Verified")
    else:
        print("FAIL: Horn Geometry Mismatch")


def test_dish_geometry():
    print("\nTesting Dish Geometry...")
    data = {
        "type": "dish",
        "frequency": 10e9,
        "dish_diameter": 0.6,
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code != 200:
        print(f"Failed: {response.text}")
        return

    result = response.json()
    if not result.get("success"):
        print(f"Dish Error: {result.get('error')}")
        return

    geoms = result["data"]["geometries"]
    dish_count = sum(1 for g in geoms if g["type"] == "dish")
    wire_count = sum(1 for g in geoms if g["type"] == "wire")
    print(f"Dish count: {dish_count}, Wire count: {wire_count}")
    if dish_count >= 1 and wire_count >= 1:
        print("PASS: Dish Geometry Verified")
    else:
        print("FAIL: Dish Geometry Mismatch")


def test_lpda_geometry():
    print("\nTesting LPDA Geometry...")
    data = {
        "type": "lpda",
        "frequency": 300e6,
        "tau": 0.86,
        "sigma": 0.15,
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code != 200:
        print(f"Failed: {response.text}")
        return

    result = response.json()
    if not result.get("success"):
        print(f"LPDA Error: {result.get('error')}")
        return

    geoms = result["data"]["geometries"]
    rect_count = sum(1 for g in geoms if g["type"] == "rectangle")
    wire_count = sum(1 for g in geoms if g["type"] == "wire")
    print(f"Rectangle count: {rect_count}, Wire count: {wire_count}")
    if rect_count >= 1 and wire_count >= 8:
        print("PASS: LPDA Geometry Verified")
    else:
        print("FAIL: LPDA Geometry Mismatch")


def test_loop_geometry():
    print("\nTesting Loop Geometry...")
    data = {
        "type": "loop",
        "frequency": 300e6,
        "radius": 0.25,
        "loop_radius": 0.25,
        "radius_wire": 0.005,
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code != 200:
        print(f"Failed: {response.text}")
        return

    result = response.json()
    if not result.get("success"):
        print(f"Loop Error: {result.get('error')}")
        return

    geoms = result["data"]["geometries"]
    wire_count = sum(1 for g in geoms if g["type"] == "wire")
    print(f"Wire count: {wire_count}")
    if 30 <= wire_count <= 34:
        print("PASS: Loop Geometry Verified")
    else:
        print("FAIL: Loop Geometry Mismatch")


if __name__ == "__main__":
    try:
        test_dipole()
        test_yagi()
        test_helix()
        test_monopole_ground()
        test_patch_geometry()
        test_horn_geometry()
        test_dish_geometry()
        test_lpda_geometry()
        test_loop_geometry()
    except Exception as e:
        print(f"Test execution failed: {e}")

