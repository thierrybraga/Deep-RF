import numpy as np
from core.constants import C0
from core.grid import FDTDGrid, GridConfig
from solver import FDTDSolver, GaussianSource, SineSource, FieldProbe
from config import AntennaConfig, SimulationConfig
from antennas import create_antenna
from state import simulations, simulation_lock

def run_fdtd_simulation(sim_id: str, antenna_config: AntennaConfig, sim_config: SimulationConfig):
    """Executa simulação FDTD em thread separada"""
    try:
        with simulation_lock:
            simulations[sim_id]['status'] = 'running'
            simulations[sim_id]['progress'] = 0
        
        # Cria antena
        antenna = create_antenna(antenna_config)
        wavelength = C0 / antenna_config.frequency
        
        # Configura grade
        dx = wavelength / sim_config.cells_per_wavelength
        
        # Dimensões baseadas na antena
        bb = antenna.get_bounding_box()
        margin = wavelength
        
        nx = max(30, int((bb.size.x + 2 * margin) / dx))
        ny = max(30, int((bb.size.y + 2 * margin) / dx))
        nz = max(40, int((bb.size.z + 2 * margin) / dx))
        
        # Limita tamanho para performance (Aumentado para suportar alta resolução)
        nx = min(nx, 200)
        ny = min(ny, 200)
        nz = min(nz, 300)
        
        config = GridConfig(
            dx=dx, nx=nx, ny=ny, nz=nz,
            pml_layers=sim_config.pml_layers,
            courant=sim_config.courant
        )
        
        grid = FDTDGrid(config)
        grid.apply_antenna(antenna)
        grid.setup_pml()
        grid.calculate_coefficients()
        
        # Inicializa Solver (Otimização Numba é automática se disponível e use_optimized=True)
        # Passamos use_numba=sim_config.use_optimized para controlar explicitamente
        solver = FDTDSolver(grid, use_numba=sim_config.use_optimized)
        
        # Fonte
        center = (config.nx // 2, config.ny // 2, config.nz // 2)
        
        if sim_config.source_type == 'gaussian':
            source = GaussianSource(
                position=center,
                component='Ez',
                amplitude=sim_config.source_amplitude,
                tau=2e-9
            )
        else:
            source = SineSource(
                position=center,
                component='Ez',
                amplitude=sim_config.source_amplitude,
                frequency=antenna_config.frequency
            )
        
        solver.add_source(source)
        
        probe = FieldProbe(position=center, component='Ez')
        solver.add_probe(probe)
        
        frames = []
        raw_slices = []
        slice_max_values = []
        
        num_steps = sim_config.num_steps
        record_interval = max(1, num_steps // 100)
        
        for step in range(num_steps):
            solver.step()
            
            progress = int((step + 1) / num_steps * 100)
            with simulation_lock:
                simulations[sim_id]['progress'] = progress
            
            if step % record_interval == 0:
                field_slice = grid.Ez[:, config.ny // 2, :].copy()
                max_val = np.max(np.abs(field_slice)) + 1e-10
                raw_slices.append((step, field_slice))
                slice_max_values.append(max_val)
        
        if raw_slices:
            global_max = max(slice_max_values)
            for (step, field_slice), local_max in zip(raw_slices, slice_max_values):
                normalized = field_slice / global_max
                frames.append({
                    'step': step,
                    'time_ns': step * config.dt * 1e9,
                    'field': normalized.tolist(),
                    'max_value': float(global_max)
                })
        
        # Dados finais
        times, values = solver.probes[0].get_time_series()
        
        # Calcula espectro
        if len(values) > 10:
            fft_vals = np.fft.fft(values)
            freqs = np.fft.fftfreq(len(values), config.dt)
            positive_mask = freqs > 0
            spectrum_freqs = freqs[positive_mask][:100]
            spectrum_vals = np.abs(fft_vals[positive_mask])[:100]
        else:
            spectrum_freqs = []
            spectrum_vals = []
        
        # Resultados
        results = {
            'status': 'completed',
            'grid': {
                'nx': config.nx, 'ny': config.ny, 'nz': config.nz,
                'dx': config.dx, 'dt': config.dt
            },
            'stats': {
                'computation_time': solver.stats.get('computation_time', 0),
                'max_E': float(solver.stats.get('max_E', 0)),
                'max_H': float(solver.stats.get('max_H', 0)),
                'num_steps': num_steps
            },
            'time_series': {
                'times': (np.array(times) * 1e9).tolist() if len(times) > 0 else [],
                'values': values.tolist() if len(values) > 0 else []
            },
            'spectrum': {
                'frequencies': (np.array(spectrum_freqs) / 1e6).tolist(),
                'magnitudes': (np.array(spectrum_vals) / (np.max(spectrum_vals) + 1e-10)).tolist()
            },
            'frames': frames,
            'field_shape': [config.nx, config.nz]
        }
        
        with simulation_lock:
            simulations[sim_id].update(results)
            simulations[sim_id]['progress'] = 100
        
    except Exception as e:
        with simulation_lock:
            simulations[sim_id]['status'] = 'error'
            simulations[sim_id]['error'] = str(e)
