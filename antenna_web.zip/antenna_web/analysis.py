import numpy as np
from core.constants import C0
from visualization.smith_chart import (
    calculate_impedance_analytical,
    ImpedanceResult,
    impedance_to_gamma,
    gamma_to_s11_db,
    gamma_to_vswr,
)
from config import AntennaConfig

def estimate_beamwidth(pattern, angles):
    """Estima largura de feixe de 3dB"""
    max_val = np.max(pattern)
    half_power = max_val / 2
    
    above_half = pattern >= half_power
    if np.any(above_half):
        indices = np.where(above_half)[0]
        return angles[indices[-1]] - angles[indices[0]]
    return 360

def calculate_radiation_pattern(antenna_config: AntennaConfig) -> dict:
    """Calcula padrão de radiação simplificado"""
    angles = np.linspace(0, 360, 361)
    theta_rad = np.radians(angles)
    
    if antenna_config.type in ['dipole', 'monopole', 'folded_dipole', 'v_dipole']:
        # Padrão de dipolo: sin²(θ)
        # No plano E (θ variando, φ=0)
        pattern_e = np.abs(np.sin(theta_rad)) ** 2
        # No plano H (θ=90°, φ variando) - omnidirecional
        pattern_h = np.ones_like(angles)
        
    elif antenna_config.type == 'yagi':
        # Padrão direcional simplificado
        n_elements = antenna_config.num_directors + 2
        # Fator de array aproximado
        pattern_e = np.abs(np.sin(theta_rad)) * np.abs(np.sinc((theta_rad - np.pi/2) * n_elements / np.pi))
        pattern_e = pattern_e / (np.max(pattern_e) + 1e-10)
        pattern_h = pattern_e
        
    elif antenna_config.type == 'patch':
        # Padrão de patch - broadside
        pattern_e = np.abs(np.cos(theta_rad - np.pi/2)) ** 2
        pattern_h = np.abs(np.cos(theta_rad - np.pi/2)) ** 2
        
    elif antenna_config.type == 'helix':
        # Padrão de hélice axial
        pattern_e = np.abs(np.cos(theta_rad - np.pi/2)) ** 4
        pattern_h = pattern_e
        
    elif antenna_config.type == 'horn':
        # Padrão de corneta (aprox. cos^q)
        # q depende da área da abertura, aqui aproximado
        q_e = 6  # Moderadamente direcional
        q_h = 4
        pattern_e = np.abs(np.cos(theta_rad - np.pi/2)) ** q_e
        pattern_h = np.abs(np.cos(theta_rad - np.pi/2)) ** q_h
        
    elif antenna_config.type == 'dish':
        # Padrão de parabólica (altamente direcional)
        # Sinc estreito
        beamwidth_deg = 10  # Aprox para prato típico
        k = 180 / beamwidth_deg
        arg = (theta_rad - np.pi/2) * k
        pattern_e = np.abs(np.sinc(arg/np.pi)) ** 2
        pattern_h = pattern_e
        
    elif antenna_config.type == 'lpda':
        # Padrão LPDA (direcionalidade média, similar a Yagi mas banda larga)
        # Costuma ter f/b ratio menor que yagi
        pattern_e = np.abs(np.cos(theta_rad - np.pi/2)) ** 3
        # Adiciona um lóbulo traseiro pequeno
        back_lobe = 0.2 * np.abs(np.cos(theta_rad + np.pi/2)) ** 2
        pattern_e = pattern_e + back_lobe
        pattern_h = pattern_e
        
    elif antenna_config.type == 'loop':
        # Loop pequeno: padrão similar ao dipolo curto mas polarização trocada
        # E-plane (plano do loop): Omnidirecional (círculo)
        # H-plane (eixo do loop): Nulo
        # Mas aqui theta=0 é eixo z (eixo do loop)
        # Então padrão é sin(theta)
        pattern_e = np.abs(np.sin(theta_rad))
        pattern_h = np.ones_like(theta_rad) # Aprox

    else:
        pattern_e = np.ones_like(angles)
        pattern_h = np.ones_like(angles)
    
    # Normaliza
    pattern_e = pattern_e / (np.max(pattern_e) + 1e-10)
    pattern_h = pattern_h / (np.max(pattern_h) + 1e-10)
    
    # Gera dados 3D simplificados (coarse mesh)
    theta_3d = np.linspace(0, np.pi, 37)  # 5 deg steps
    phi_3d = np.linspace(0, 2*np.pi, 73)
    
    mesh_points = []
    
    THETA, PHI = np.meshgrid(theta_3d, phi_3d, indexing='ij')
    
    if antenna_config.type in ['dipole', 'monopole', 'folded_dipole', 'v_dipole']:
        R = np.abs(np.sin(THETA)) ** 2
    elif antenna_config.type == 'yagi':
        n_elements = antenna_config.num_directors + 2
        R = np.abs(np.sin(THETA)) * np.abs(np.sinc((THETA - np.pi/2) * n_elements / np.pi))
    elif antenna_config.type == 'patch':
        R = np.abs(np.cos(THETA - np.pi/2)) ** 2 * (np.sin(PHI)**2 + 1)/2
    elif antenna_config.type == 'helix':
        R = np.abs(np.cos(THETA - np.pi/2)) ** 4
    elif antenna_config.type == 'horn':
        R = np.abs(np.cos(THETA - np.pi/2)) ** 5 * (np.cos(PHI)**2 * 0.5 + 0.5)
    elif antenna_config.type == 'dish':
        arg = (THETA - np.pi/2) * (180/10) # usando mesmo k de cima
        R = np.abs(np.sinc(arg/np.pi)) ** 2
    elif antenna_config.type == 'lpda':
        R = np.abs(np.cos(THETA - np.pi/2)) ** 3
        # Lóbulo traseiro simplificado
        R += 0.2 * np.abs(np.cos(THETA + np.pi/2)) ** 2
    elif antenna_config.type == 'loop':
        # Loop (eixo z): padrão toroidal sin(theta)
        R = np.abs(np.sin(THETA))
    else:
        R = np.ones_like(THETA)
        
    # Normaliza R 3D
    R = R / (np.max(R) + 1e-10)
    
    # Converte para lista compacta para JSON
    # Vamos enviar apenas os valores de R, o frontend sabe reconstruir a esfera
    pattern_3d = R.tolist()

    return {
        'angles': angles.tolist(),
        'pattern_e': pattern_e.tolist(),
        'pattern_h': pattern_h.tolist(),
        'pattern_3d': pattern_3d,
        'directivity_db': 10 * np.log10(np.max(pattern_e)**2 * 1.5 + 1e-10) + 2.15, # Est.
        '3db_beamwidth': estimate_beamwidth(pattern_e, angles)
    }

def calculate_smith_chart_data(antenna_config: AntennaConfig) -> dict:
    """Calcula dados para Carta de Smith"""
    wavelength = C0 / antenna_config.frequency
    
    # Frequências de análise
    freq_center = antenna_config.frequency
    freq_min = freq_center * 0.5
    freq_max = freq_center * 1.5
    frequencies = np.linspace(freq_min, freq_max, 101)
    
    if antenna_config.type in ['dipole', 'yagi', 'folded_dipole', 'v_dipole']:
        length = antenna_config.length or wavelength / 2
        antenna_type = 'dipole'
    elif antenna_config.type == 'monopole':
        length = antenna_config.length or wavelength / 4
        antenna_type = 'monopole'
    elif antenna_config.type == 'patch':
        length = None
        antenna_type = 'patch'
    else:
        length = wavelength / 2
        antenna_type = 'dipole'
    
    base_result = calculate_impedance_analytical(
        antenna_type,
        frequencies,
        length=length,
        z0=50.0,
        substrate_er=antenna_config.substrate_er,
        substrate_h=antenna_config.substrate_h,
        f_resonant=freq_center
    )
    
    # Ajuste para dipolo dobrado: resistência aproximadamente 4× a do dipolo simples
    if antenna_config.type == 'folded_dipole':
        impedance = base_result.impedance * 4.0
        gamma = np.array([impedance_to_gamma(z, base_result.z0) for z in impedance])
        s11_db = np.array([gamma_to_s11_db(g) for g in gamma])
        vswr = np.array([gamma_to_vswr(g) for g in gamma])
        
        result = ImpedanceResult(
            frequencies=base_result.frequencies,
            impedance=impedance,
            gamma=gamma,
            s11_db=s11_db,
            vswr=vswr,
            z0=base_result.z0
        )
    else:
        result = base_result
    
    # Dados para Carta de Smith
    gamma_real = np.real(result.gamma).tolist()
    gamma_imag = np.imag(result.gamma).tolist()
    
    # Encontra pontos importantes
    resonance = result.find_resonance()
    best_match = result.find_best_match()
    bandwidth = result.get_bandwidth(-10.0)
    
    return {
        'frequencies_mhz': (frequencies / 1e6).tolist(),
        'impedance_real': result.resistance.tolist(),
        'impedance_imag': result.reactance.tolist(),
        'gamma_real': gamma_real,
        'gamma_imag': gamma_imag,
        's11_db': result.s11_db.tolist(),
        'vswr': np.clip(result.vswr, 1, 20).tolist(),
        'z0': result.z0,
        'resonance': {
            'frequency_mhz': resonance['frequency'] / 1e6,
            'impedance': f"{resonance['resistance']:.1f} + j{resonance['reactance']:.1f}",
            's11_db': resonance['s11_db'],
            'vswr': resonance['vswr']
        },
        'best_match': {
            'frequency_mhz': best_match['frequency'] / 1e6,
            'impedance': f"{best_match['resistance']:.1f} + j{best_match['reactance']:.1f}",
            's11_db': best_match['s11_db'],
            'vswr': best_match['vswr']
        },
        'bandwidth': {
            'min_mhz': bandwidth[0] / 1e6,
            'max_mhz': bandwidth[1] / 1e6,
            'width_mhz': bandwidth[2] / 1e6,
            'percent': 100 * bandwidth[2] / freq_center if bandwidth[2] > 0 else 0
        }
    }

def calculate_parameters(frequency: float, directivity_db: float | None = None, efficiency: float = 0.9) -> dict:
    wavelength = C0 / frequency
    
    params = {
        'frequency_hz': frequency,
        'frequency_mhz': frequency / 1e6,
        'wavelength_m': wavelength,
        'wavelength_cm': wavelength * 100,
        'half_wavelength_cm': wavelength * 50,
        'quarter_wavelength_cm': wavelength * 25,
        'k': 2 * np.pi / wavelength,
        'omega': 2 * np.pi * frequency
    }
    
    if directivity_db is not None:
        gain_db = directivity_db + 10 * np.log10(efficiency)
        params['directivity_db'] = directivity_db
        params['gain_db'] = gain_db
        params['efficiency'] = efficiency
    
    return params
