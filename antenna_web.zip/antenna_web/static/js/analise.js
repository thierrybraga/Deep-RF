class AnalisePage {
    constructor() {
        this.renderer = null;
        this.chartManager = new ChartManager();
        this.state = this.readParams();
        this.init();
    }

    readParams() {
        const params = new URLSearchParams(window.location.search);
        const type = params.get('type') || 'dipole';
        const freqMHz = parseFloat(params.get('freq_mhz') || '300');
        const length = params.get('length') ? parseFloat(params.get('length')) : null;
        const numDirectors = params.get('num_directors') ? parseInt(params.get('num_directors')) : 3;
        return {
            antennaType: type,
            frequency: freqMHz * 1e6,
            length,
            numDirectors
        };
    }

    async init() {
        this.renderer = new AntennaRenderer('analise-canvas-3d');
        await this.loadAntenna();
        await this.loadAnalysis();
    }

    async loadAntenna() {
        const body = {
            type: this.state.antennaType,
            frequency: this.state.frequency,
            length: this.state.length,
            num_directors: this.state.numDirectors
        };
        const res = await fetch('/api/antenna/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const json = await res.json();
        if (!json.success) return;
        const data = json.data;
        this.renderer.renderAntenna(data);
        this.updateInfo(data);
    }

    async loadAnalysis() {
        const basePayload = {
            type: this.state.antennaType,
            frequency: this.state.frequency,
            length: this.state.length,
            num_directors: this.state.numDirectors
        };

        const smithRes = await fetch('/api/smith-chart', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(basePayload)
        });
        const smithJson = await smithRes.json();
        if (smithJson.success) {
            const smithData = smithJson.data;
            const smithCanvas = document.getElementById('analise-smith-canvas');
            if (smithCanvas) {
                this.chartManager.smithCanvas = smithCanvas;
                this.chartManager.smithCtx = smithCanvas.getContext('2d');
                this.chartManager.drawSmithGrid();
            }
            this.chartManager.updateSmithChart(smithData);
            this.updateSmithInfo(smithData);
            const s11Canvas = document.getElementById('analise-s11-canvas');
            if (s11Canvas) {
                this.chartManager.charts.s11 = new Chart(s11Canvas, this.chartManager.charts.s11?.config || this.chartManager.charts.s11);
            }
            this.chartManager.updateS11Chart(smithData);
        }

        const radRes = await fetch('/api/radiation-pattern', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(basePayload)
        });
        const radJson = await radRes.json();
        if (radJson.success) {
            const rad = radJson.data;
            const radCanvas = document.getElementById('analise-rad-e-canvas');
            if (radCanvas) {
                this.chartManager.charts.radiation = new Chart(radCanvas, this.chartManager.charts.radiation?.config || this.chartManager.charts.radiation);
            }
            this.chartManager.updateRadiationChart(rad);
            this.updateRadiationInfo(rad);
        }
    }

    updateInfo(antennaData) {
        const freqMHz = (antennaData.frequency / 1e6).toFixed(0);
        const lambda = antennaData.wavelength;
        document.getElementById('analise-type').textContent = this.state.antennaType;
        document.getElementById('analise-freq').textContent = freqMHz + ' MHz';
        document.getElementById('analise-lambda').textContent = lambda.toFixed(3) + ' m';
    }

    updateSmithInfo(data) {
        const res = data.resonance;
        const best = data.best_match;
        const bw = data.bandwidth;
        const resText = res.frequency_mhz.toFixed(1) + ' MHz, ' + res.impedance + ', S11=' + res.s11_db.toFixed(1) + ' dB';
        const bestText = best.frequency_mhz.toFixed(1) + ' MHz, ' + best.impedance + ', VSWR=' + best.vswr.toFixed(2);
        const bwText = bw.min_mhz.toFixed(1) + '–' + bw.max_mhz.toFixed(1) + ' MHz (' + bw.percent.toFixed(1) + '%)';
        document.getElementById('analise-resonancia').textContent = resText;
        document.getElementById('analise-bestmatch').textContent = bestText;
        document.getElementById('analise-bandwidth').textContent = bwText;
    }

    updateRadiationInfo(rad) {
        const d = rad.directivity_db.toFixed(1) + ' dBi';
        const bw = rad['3db_beamwidth'].toFixed(1) + '°';
        document.getElementById('analise-directivity').textContent = d;
        document.getElementById('analise-beamwidth').textContent = bw;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new AnalisePage();
});
