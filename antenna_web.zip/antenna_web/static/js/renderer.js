/**
 * AntennaSim - Engine de Renderização 3D Avançada
 * Three.js com shaders customizados, partículas, pós-processamento
 * @version 2.0.0
 */

// ============================================================================
// CONFIGURAÇÃO GLOBAL
// ============================================================================

const RENDER_CONFIG = {
    quality: {
        low: { pixelRatio: 1, shadows: false, antialias: false },
        medium: { pixelRatio: 1.5, shadows: true, antialias: true },
        high: { pixelRatio: 2, shadows: true, antialias: true }
    },
    camera: {
        fov: 50,
        near: 0.001,
        far: 1000,
        defaultPosition: { x: 2, y: 1.5, z: 2 }
    },
    field: {
        scale: 1.0
    },
    materials: {
        copper: { color: 0xb87333, metalness: 0.95, roughness: 0.25 },
        aluminum: { color: 0x909090, metalness: 0.95, roughness: 0.15 },
        gold: { color: 0xffd700, metalness: 1.0, roughness: 0.1 },
        silver: { color: 0xc0c0c0, metalness: 1.0, roughness: 0.1 },
        pcb: { color: 0x1a5f1a, metalness: 0.1, roughness: 0.8 },
        teflon: { color: 0xffffff, metalness: 0.0, roughness: 0.9, transmission: 0.5, opacity: 0.8, transparent: true }
    }
};

// ============================================================================
// CLASSE: AntennaRenderer
// ============================================================================

class AntennaRenderer {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) {
            console.error('Canvas não encontrado:', canvasId);
            return;
        }
        
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.clock = new THREE.Clock();
        this.mouse = new THREE.Vector2();
        this.raycaster = new THREE.Raycaster();
        
        this.antennaGroup = new THREE.Group();
        this.helpersGroup = new THREE.Group();
        this.fieldGroup = new THREE.Group();
        this.particleSystem = null;
        
        this.materials = {};
        this.animationId = null;
        this.isAnimating = true;
        
        this.fieldPlane = null;
        this.fieldTexture = null;
        this.antennaScale = 1;
        this.antennaInfo = null;
        
        this.settings = {
            showGrid: true,
            showAxes: true,
            showRadiation: false,
            showField3D: true,
            autoRotate: false,
            quality: 'high'
        };
        
        this.init();
    }
    
    hasWebGLSupport() {
        try {
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl2') || canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            return !!gl;
        } catch (e) {
            console.error('Falha ao verificar suporte WebGL', e);
            return false;
        }
    }
    
    init() {
        this.createRenderer();
        if (!this.renderer) {
            return;
        }
        this.createScene();
        this.createCamera();
        this.createControls();
        this.createLights();
        this.createMaterials();
        this.createHelpers();
        this.setupInteraction();
        
        window.addEventListener('resize', () => this.onResize());
        this.onResize();
        
        this.animate();
        this.hideLoading();
        
        console.log('🎮 AntennaRenderer inicializado');
    }

    setupInteraction() {
        this.canvas.addEventListener('click', (event) => {
            // Calculate mouse position in normalized device coordinates (-1 to +1)
            const rect = this.canvas.getBoundingClientRect();
            this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            this.raycaster.setFromCamera(this.mouse, this.camera);

            // Intersect with antenna objects
            const intersects = this.raycaster.intersectObjects(this.antennaGroup.children, true);

            if (intersects.length > 0) {
                // Clicked on antenna
                console.log('Antenna clicked!');
                const customEvent = new CustomEvent('antenna-click', {
                    detail: { point: intersects[0].point }
                });
                this.canvas.dispatchEvent(customEvent);
            }
        });
    }
    
    createRenderer() {
        if (!this.hasWebGLSupport()) {
            console.error('WebGL não disponível ou desativado neste ambiente');
            this.showWebGLError();
            return;
        }
        
        const quality = RENDER_CONFIG.quality[this.settings.quality];
        
        try {
            const contextAttributes = {
                alpha: true,
                antialias: quality.antialias,
                powerPreference: 'high-performance',
                failIfMajorPerformanceCaveat: false,
                preserveDrawingBuffer: true
            };

            this.renderer = new THREE.WebGLRenderer({
                canvas: this.canvas,
                ...contextAttributes
            });
        } catch (e) {
            console.warn('Falha ao criar WebGLRenderer com alta performance, tentando fallback...', e);
            try {
                // Tenta fallback com configurações mínimas
                this.renderer = new THREE.WebGLRenderer({
                    canvas: this.canvas,
                    alpha: true,
                    antialias: false,
                    powerPreference: 'default',
                    failIfMajorPerformanceCaveat: true
                });
            } catch (e2) {
                console.error('Erro fatal: WebGL não suportado', e2);
                this.showWebGLError();
                return;
            }
        }

        if (!this.renderer) {
            this.showWebGLError();
            return;
        }
        
        // Handle Context Loss
        this.canvas.addEventListener('webglcontextlost', (e) => {
            e.preventDefault();
            console.log('WebGL Context Lost');
            this.cancelAnimation();
        }, false);

        this.canvas.addEventListener('webglcontextrestored', () => {
            console.log('WebGL Context Restored');
            // Re-initialize scene
            this.renderer = null;
            this.init(); 
        }, false);
        
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, quality.pixelRatio));
        this.renderer.setSize(this.canvas.clientWidth, this.canvas.clientHeight);
        
        if (this.renderer.shadowMap) {
            this.renderer.shadowMap.enabled = quality.shadows;
            this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        }
        
        this.renderer.outputEncoding = THREE.sRGBEncoding;
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1.2;
        
        // Ativa features avançadas se disponível
        if (this.renderer.capabilities.isWebGL2) {
            console.log('WebGL 2 suportado e ativo');
        }
    }

    showWebGLError() {
        const errorMsg = document.createElement('div');
        errorMsg.style.cssText = 'position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); color:#ff4444; background:rgba(0,0,0,0.9); padding:20px; border-radius:8px; text-align:center; z-index:1000; font-family: sans-serif; box-shadow: 0 4px 6px rgba(0,0,0,0.3); border: 1px solid #ff4444;';
        errorMsg.innerHTML = '<h3 style="margin-top:0">Erro Gráfico 3D</h3><p>Não foi possível inicializar o motor de renderização (WebGL).</p><p>Sugestões:</p><ul style="text-align:left; font-size:0.9em"><li>Atualize seus drivers de vídeo</li><li>Ative a aceleração de hardware no navegador</li><li>Tente outro navegador (Chrome, Firefox, Edge)</li></ul>';
        
        const container = this.canvas.parentElement;
        if (container) {
            const existing = container.querySelector('div[style*="color:#ff4444"]');
            if (existing) existing.remove();
            container.appendChild(errorMsg);
        }
    }

    cancelAnimation() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
        this.isAnimating = false;
    }
    
    createScene() {
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x0a0a1a);
        this.scene.fog = new THREE.FogExp2(0x0a0a1a, 0.12);
        
        this.scene.add(this.antennaGroup);
        this.scene.add(this.helpersGroup);
        this.scene.add(this.fieldGroup);
    }
    
    createCamera() {
        const aspect = this.canvas.clientWidth / this.canvas.clientHeight;
        const { fov, near, far, defaultPosition } = RENDER_CONFIG.camera;
        
        this.camera = new THREE.PerspectiveCamera(fov, aspect, near, far);
        this.camera.position.set(defaultPosition.x, defaultPosition.y, defaultPosition.z);
    }
    
    createControls() {
        this.controls = new THREE.OrbitControls(this.camera, this.canvas);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.05;
        this.controls.rotateSpeed = 0.8;
        this.controls.zoomSpeed = 1.2;
        this.controls.minDistance = 0.1;
        this.controls.maxDistance = 50;
        this.controls.target.set(0, 0, 0);
    }
    
    createLights() {
        // Ambient
        const ambient = new THREE.AmbientLight(0xffffff, 0.4);
        this.scene.add(ambient);
        
        // Key light
        const keyLight = new THREE.DirectionalLight(0xffffff, 1.0);
        keyLight.position.set(5, 5, 5);
        keyLight.castShadow = true;
        keyLight.shadow.mapSize.width = 2048;
        keyLight.shadow.mapSize.height = 2048;
        keyLight.shadow.camera.near = 0.1;
        keyLight.shadow.camera.far = 50;
        this.scene.add(keyLight);
        
        // Fill light
        const fillLight = new THREE.DirectionalLight(0x88aaff, 0.3);
        fillLight.position.set(-3, 2, -3);
        this.scene.add(fillLight);
        
        // Rim light
        const rimLight = new THREE.PointLight(0xff8866, 0.2, 20);
        rimLight.position.set(0, -3, -5);
        this.scene.add(rimLight);
        
        // Hemisphere
        const hemiLight = new THREE.HemisphereLight(0x88aaff, 0x444422, 0.3);
        this.scene.add(hemiLight);
    }
    
    createMaterials() {
        for (const [name, props] of Object.entries(RENDER_CONFIG.materials)) {
            const matConfig = {
                color: props.color,
                metalness: props.metalness,
                roughness: props.roughness,
                clearcoat: props.metalness > 0.5 ? 0.3 : 0,
                clearcoatRoughness: 0.2
            };

            if (props.transparent) {
                matConfig.transparent = true;
                matConfig.opacity = props.opacity || 1.0;
            }
            
            if (props.transmission) {
                matConfig.transmission = props.transmission;
            }

            this.materials[name] = new THREE.MeshPhysicalMaterial(matConfig);
        }
        
        this.materials.feed = new THREE.MeshBasicMaterial({
            color: 0xff4444,
            transparent: true,
            opacity: 0.9
        });
        
        this.materials.glow = new THREE.MeshBasicMaterial({
            color: 0xff6644,
            transparent: true,
            opacity: 0.3
        });
        
        this.materials.ground = new THREE.MeshStandardMaterial({
            color: 0x222233,
            metalness: 0.3,
            roughness: 0.8,
            transparent: true,
            opacity: 0.5
        });
    }
    
    createHelpers() {
        // Grid
        this.gridHelper = new THREE.GridHelper(4, 40, 0x00ffff, 0x004444);
        this.gridHelper.position.y = -0.5;
        this.gridHelper.material.transparent = true;
        this.gridHelper.material.opacity = 0.3;
        this.helpersGroup.add(this.gridHelper);
        
        // Axes
        this.axesHelper = new THREE.AxesHelper(0.5);
        this.helpersGroup.add(this.axesHelper);
        
        // Axis labels
        this.createAxisLabels();
        
        // Ground
        const groundGeom = new THREE.PlaneGeometry(10, 10);
        groundGeom.rotateX(-Math.PI / 2);
        const ground = new THREE.Mesh(groundGeom, this.materials.ground);
        ground.position.y = -0.51;
        ground.receiveShadow = true;
        this.scene.add(ground);
    }
    
    createAxisLabels() {
        const labels = [
            { text: 'X', color: '#ff4444', pos: [0.6, 0, 0] },
            { text: 'Y', color: '#44ff44', pos: [0, 0.6, 0] },
            { text: 'Z', color: '#4444ff', pos: [0, 0, 0.6] }
        ];
        
        labels.forEach(({ text, color, pos }) => {
            const sprite = this.createTextSprite(text, color);
            sprite.position.set(...pos);
            sprite.scale.set(0.12, 0.12, 0.12);
            this.helpersGroup.add(sprite);
        });
    }
    
    createTextSprite(text, color) {
        const canvas = document.createElement('canvas');
        canvas.width = 64;
        canvas.height = 64;
        
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = color;
        ctx.font = 'bold 48px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, 32, 32);
        
        const texture = new THREE.CanvasTexture(canvas);
        const material = new THREE.SpriteMaterial({ map: texture, transparent: true });
        return new THREE.Sprite(material);
    }
    
    onResize() {
        if (!this.camera || !this.renderer) return;

        const width = this.canvas.clientWidth;
        const height = this.canvas.clientHeight;
        
        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(width, height, false);
    }
    
    animate() {
        if (!this.renderer || !this.scene || !this.camera) return;

        this.animationId = requestAnimationFrame(() => this.animate());
        
        if (!this.isAnimating) return;
        
        const delta = this.clock.getDelta();
        const elapsed = this.clock.getElapsedTime();
        
        this.controls.update();
        
        // Auto rotate
        if (this.settings.autoRotate) {
            this.antennaGroup.rotation.y += delta * 0.3;
        }
        
        // Animate feed point
        this.antennaGroup.children.forEach(child => {
            if (child.userData.isFeed) {
                const scale = 1 + Math.sin(elapsed * 4) * 0.1;
                child.scale.setScalar(scale);
            }
        });
        
        // Update particles
        if (this.particleSystem) {
            this.updateParticles(delta);
        }
        
        this.renderer.render(this.scene, this.camera);
    }
    
    // ========================================================================
    // ANTENNA RENDERING
    // ========================================================================
    
    clearAntenna() {
        while (this.antennaGroup.children.length > 0) {
            const child = this.antennaGroup.children[0];
            if (child.geometry) child.geometry.dispose();
            if (child.material) {
                if (Array.isArray(child.material)) {
                    child.material.forEach(m => m.dispose());
                } else {
                    child.material.dispose();
                }
            }
            this.antennaGroup.remove(child);
        }
        
        if (this.particleSystem) {
            this.scene.remove(this.particleSystem);
            this.particleSystem = null;
        }
    }
    
    renderAntenna(data) {
        if (!data || !data.geometries) {
            console.warn('Dados de antena inválidos');
            return;
        }
        
        this.clearAntenna();
        
        const scale = this.calculateScale(data.bounding_box);
        this.antennaScale = scale;
        this.antennaInfo = {
            boundingBox: data.bounding_box,
            wavelength: data.wavelength,
            frequency: data.frequency
        };
        const center = new THREE.Vector3(
            data.bounding_box.center[0] * scale,
            data.bounding_box.center[1] * scale,
            data.bounding_box.center[2] * scale
        );
        
        data.geometries.forEach(geom => {
            const mesh = this.createGeometryMesh(geom, scale, center);
            if (mesh) {
                mesh.castShadow = true;
                mesh.receiveShadow = true;
                this.antennaGroup.add(mesh);
            }
        });
        
        if (data.feed_point) {
            const feed = this.createFeedPoint(data.feed_point, scale, center);
            feed.userData.isFeed = true;
            this.antennaGroup.add(feed);
        }
        
        if (this.settings.showRadiation && data.radiation) {
            this.setRadiationData(data.radiation);
        }
        
        this.fitCameraToObject();
        console.log('📡 Antena renderizada:', data.geometries.length, 'geometrias');
    }
    
    calculateScale(bbox) {
        const maxDim = Math.max(bbox.size[0], bbox.size[1], bbox.size[2]);
        return maxDim > 0 ? 1.5 / maxDim : 1;
    }
    
    createGeometryMesh(geom, scale, center) {
        let mesh;
        
        switch (geom.type) {
            case 'wire':
                mesh = this.createWire(geom, scale);
                break;
            case 'rectangle':
                mesh = this.createRectangle(geom, scale);
                break;
            case 'cylinder':
                mesh = this.createCylinder(geom, scale);
                break;
            case 'helix':
                mesh = this.createHelix(geom, scale);
                break;
            case 'horn':
                mesh = this.createHorn(geom, scale);
                break;
            case 'dish':
                mesh = this.createDish(geom, scale);
                break;
            default:
                return null;
        }
        
        if (mesh) mesh.position.sub(center);
        return mesh;
    }
    
    createWire(geom, scale) {
        const start = new THREE.Vector3(...geom.start).multiplyScalar(scale);
        const end = new THREE.Vector3(...geom.end).multiplyScalar(scale);
        
        const direction = new THREE.Vector3().subVectors(end, start);
        const length = direction.length();
        const radius = Math.max(geom.radius * scale, 0.004);
        
        // Aumentado para 32 segmentos para melhor visualização (várias arestas)
        const geometry = new THREE.CylinderGeometry(radius, radius, length, 32);
        const material = this.getMaterial(geom.material);
        const mesh = new THREE.Mesh(geometry, material);
        
        const midpoint = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5);
        mesh.position.copy(midpoint);
        mesh.quaternion.setFromUnitVectors(
            new THREE.Vector3(0, 1, 0),
            direction.normalize()
        );
        
        return mesh;
    }
    
    createRectangle(geom, scale) {
        const width = geom.width * scale;
        const height = geom.height * scale;
        
        const geometry = new THREE.BoxGeometry(width, 0.003, height);
        const material = this.getMaterial(geom.material);
        const mesh = new THREE.Mesh(geometry, material);
        
        mesh.position.set(
            geom.center[0] * scale,
            geom.center[1] * scale,
            geom.center[2] * scale
        );
        
        const normal = new THREE.Vector3(...geom.normal);
        mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
        
        return mesh;
    }
    
    createCylinder(geom, scale) {
        const radius = geom.radius * scale;
        const height = geom.height * scale;
        
        // Aumentado para 64 segmentos para melhor visualização
        const geometry = new THREE.CylinderGeometry(radius, radius, height, 64);
        const material = this.getMaterial(geom.material);
        const mesh = new THREE.Mesh(geometry, material);
        
        mesh.position.set(
            geom.base[0] * scale,
            geom.base[1] * scale + height / 2,
            geom.base[2] * scale
        );
        
        return mesh;
    }
    
    createHelix(geom, scale) {
        const points = geom.points.map(p =>
            new THREE.Vector3(p[0] * scale, p[1] * scale, p[2] * scale)
        );
        
        const curve = new THREE.CatmullRomCurve3(points);
        const tubeRadius = Math.max((geom.wire_radius || 0.001) * scale, 0.004);
        
        // Aumentado para 300 segmentos e 16 radiais para maior suavidade
        const geometry = new THREE.TubeGeometry(curve, 300, tubeRadius, 16, false);
        const material = this.getMaterial(geom.material);
        
        return new THREE.Mesh(geometry, material);
    }

    createHorn(geom, scale) {
        // Dimensões
        const tw = geom.throat_width * scale;
        const th = geom.throat_height * scale;
        const aw = geom.aperture_width * scale;
        const ah = geom.aperture_height * scale;
        const len = geom.length * scale;
        
        const material = this.getMaterial(geom.material);
        material.side = THREE.DoubleSide;
        
        // Vértices
        // Throat (z=0)
        const t1 = [-tw/2, -th/2, 0];
        const t2 = [tw/2, -th/2, 0];
        const t3 = [tw/2, th/2, 0];
        const t4 = [-tw/2, th/2, 0];
        
        // Aperture (z=len)
        const a1 = [-aw/2, -ah/2, len];
        const a2 = [aw/2, -ah/2, len];
        const a3 = [aw/2, ah/2, len];
        const a4 = [-aw/2, ah/2, len];
        
        // Faces (2 triângulos por parede)
        const vertices = [
            // Bottom wall
            ...t1, ...t2, ...a2,
            ...t1, ...a2, ...a1,
            // Top wall
            ...t4, ...a3, ...t3,
            ...t4, ...a4, ...a3,
            // Right wall
            ...t2, ...t3, ...a3,
            ...t2, ...a3, ...a2,
            // Left wall
            ...t1, ...a4, ...t4,
            ...t1, ...a1, ...a4
        ];
        
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
        geometry.computeVertexNormals();
        
        const mesh = new THREE.Mesh(geometry, material);
        
        mesh.position.set(
            geom.center[0] * scale,
            geom.center[1] * scale,
            geom.center[2] * scale
        );
        
        return mesh;
    }

    createDish(geom, scale) {
        const diameter = geom.diameter * scale;
        const f = geom.focal_length * scale;
        
        // Curva parabólica: y = x^2 / (4f)
        const points = [];
        const segments = 40;
        const radius = diameter / 2;
        
        for (let i = 0; i <= segments; i++) {
            const x = (i / segments) * radius;
            const y = (x * x) / (4 * f);
            points.push(new THREE.Vector2(x, y));
        }
        
        const geometry = new THREE.LatheGeometry(points, 64);
        const material = this.getMaterial(geom.material);
        material.side = THREE.DoubleSide;
        
        const mesh = new THREE.Mesh(geometry, material);
        
        // Alinhar ao eixo
        const axis = new THREE.Vector3(...geom.axis).normalize();
        const defaultAxis = new THREE.Vector3(0, 1, 0); // Lathe gira em torno de Y
        mesh.quaternion.setFromUnitVectors(defaultAxis, axis);
        
        mesh.position.set(
            geom.center[0] * scale,
            geom.center[1] * scale,
            geom.center[2] * scale
        );
        
        return mesh;
    }
    
    createFeedPoint(feedPoint, scale, center) {
        const group = new THREE.Group();
        
        const sphereGeom = new THREE.SphereGeometry(0.02, 24, 24);
        const sphere = new THREE.Mesh(sphereGeom, this.materials.feed);
        group.add(sphere);
        
        const glowGeom = new THREE.SphereGeometry(0.03, 16, 16);
        const glow = new THREE.Mesh(glowGeom, this.materials.glow);
        group.add(glow);
        
        group.position.set(
            feedPoint[0] * scale - center.x,
            feedPoint[1] * scale - center.y,
            feedPoint[2] * scale - center.z
        );
        
        return group;
    }
    
    getMaterial(name) {
        const key = (name || 'copper').toLowerCase();
        return this.materials[key] || this.materials.copper;
    }
    
    // ========================================================================
    // PARTICLE SYSTEM
    // ========================================================================
    
    createRadiationMesh() {
        if (!this.radiationData || !this.scene) {
            return; 
        }

        const thetaSegments = 36;
        const phiSegments = 72;
        const geometry = new THREE.SphereGeometry(1, phiSegments, thetaSegments);
        
        const positionAttribute = geometry.attributes.position;
        const vertex = new THREE.Vector3();
        const colors = [];
        const color = new THREE.Color();
        
        // Colormap (Jet-like)
        const getJetColor = (v) => {
            let r, g, b;
            if (v < 0.35) {
                r = 0;
                g = v / 0.35;
                b = 1;
            } else if (v < 0.66) {
                r = (v - 0.35) / 0.31;
                g = 1;
                b = 1 - r;
            } else {
                r = 1;
                g = 1 - (v - 0.66) / 0.34;
                b = 0;
            }
            return {r, g, b};
        };

        // Modificar vértices baseado nos dados
        // pattern_3d[theta_idx][phi_idx]
        // Three.js SphereGeometry ordena vértices:
        // y é up (mas no nosso caso Z é up?)
        // Vamos iterar e mapear
        
        for (let i = 0; i < positionAttribute.count; i++) {
            vertex.fromBufferAttribute(positionAttribute, i);
            
            // Converter para coordenadas esféricas para encontrar índice
            // Three.js: y é up. theta é polar angle from +y (0..PI)
            // phi é azimuth no plano xz (-PI..PI or 0..2PI)
            // Mas nosso sistema de coordenadas pode ser diferente.
            // Assumindo Y-up no Three.js padrão da geometria
            
            // radius = 1
            const r_base = 1.0;
            
            // Calcular theta e phi do vértice
            const theta = Math.acos(Math.max(-1, Math.min(1, vertex.y / r_base))); // 0 to PI
            const phi = Math.atan2(vertex.z, vertex.x); // -PI to PI
            
            // Normalizar para índices do array
            const thetaIdx = Math.min(36, Math.floor((theta / Math.PI) * 36));
            
            let phiNorm = phi;
            if (phiNorm < 0) phiNorm += 2 * Math.PI;
            const phiIdx = Math.min(72, Math.floor((phiNorm / (2 * Math.PI)) * 72));
            
            // Buscar valor de ganho (interpolado ou nearest)
            let gain = 0;
            if (this.radiationData && this.radiationData[thetaIdx]) {
                gain = this.radiationData[thetaIdx][phiIdx] || 0;
            }
            
            // Aplicar ganho ao raio
            const r_new = 0.1 + gain * 1.5; // Escala visual
            
            vertex.normalize().multiplyScalar(r_new);
            
            positionAttribute.setXYZ(i, vertex.x, vertex.y, vertex.z);
            
            // Cor baseada no ganho
            const c = getJetColor(gain);
            colors.push(c.r, c.g, c.b);
        }
        
        geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
        geometry.computeVertexNormals();
        
        const material = new THREE.MeshPhongMaterial({
            vertexColors: true,
            shininess: 30,
            transparent: true,
            opacity: 0.8,
            side: THREE.DoubleSide,
            wireframe: false
        });
        
        this.radiationMesh = new THREE.Mesh(geometry, material);
        
        // Ajustar orientação para coincidir com a antena
        // No nosso simulador, Z é geralmente o eixo da antena (dipolo vertical)
        // No Three.js SphereGeometry, Y é o eixo polar.
        // Se a antena está em Y, ok. Se está em Z, precisamos rotacionar.
        // O renderer.js parece usar Y como up?
        // gridHelper está no plano XZ (padrão Three.js). Y é Up.
        // Antena dipole cria geometria cylinder ao longo de Y?
        // Vamos verificar createDipole() se possível, mas assumindo Y-up.
        
        this.scene.add(this.radiationMesh);
        
        // Adicionar wireframe overlay para melhor visualização
        const wireGeo = new THREE.WireframeGeometry(geometry);
        const wireMat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.15 });
        this.radiationWireframe = new THREE.LineSegments(wireGeo, wireMat);
        this.radiationMesh.add(this.radiationWireframe);
    }
    
    setRadiationData(data) {
        this.radiationData = data;
        if (this.settings.showRadiation) {
            // Atualizar visualização se estiver visível
            if (this.radiationMesh) {
                this.scene.remove(this.radiationMesh);
                if (this.radiationMesh.geometry) this.radiationMesh.geometry.dispose();
                this.radiationMesh = null;
            }
            this.createRadiationMesh();
        }
    }

    toggleRadiation() {
        this.settings.showRadiation = !this.settings.showRadiation;
        
        if (this.settings.showRadiation) {
            if (!this.radiationMesh && this.radiationData) {
                this.createRadiationMesh();
            } else if (this.radiationMesh) {
                this.radiationMesh.visible = true;
            }
        } else {
            if (this.radiationMesh) {
                this.radiationMesh.visible = false;
            }
        }
        
        return this.settings.showRadiation;
    }
    
    // ========================================================================
    // FIELD VISUALIZATION 3D (SHADER BASED)
    // ========================================================================
    
    setupFieldVisualization(gridInfo, scale = 1.0) {
        if (!gridInfo) return;
        
        // Remove anterior
        if (this.fieldPlane) {
            this.fieldGroup.remove(this.fieldPlane);
            this.fieldPlane.geometry.dispose();
            this.fieldPlane.material.dispose();
            if (this.fieldTexture) this.fieldTexture.dispose();
            this.fieldPlane = null;
        }
        
        const { nx, nz, dx } = gridInfo;
        const fieldScale = RENDER_CONFIG.field && typeof RENDER_CONFIG.field.scale === 'number'
            ? RENDER_CONFIG.field.scale
            : 1.0;
        const width = nx * dx * scale * fieldScale;
        const depth = nz * dx * scale * fieldScale;
        
        // Geometria do plano (XZ plane)
        const geometry = new THREE.PlaneGeometry(width, depth, nx - 1, nz - 1);
        geometry.rotateX(-Math.PI / 2); // Rota para ficar no plano XZ
        
        // Textura de dados (Float se possível, senão Byte)
        const size = nx * nz;
        let type = THREE.UnsignedByteType;
        let format = THREE.RedFormat;
        
        if (!this.renderer.capabilities.isWebGL2) {
            format = THREE.LuminanceFormat;
        }

        const data = new Uint8Array(size); 
        
        this.fieldTexture = new THREE.DataTexture(data, nx, nz);
        this.fieldTexture.format = format;
        this.fieldTexture.type = type;
        this.fieldTexture.minFilter = THREE.LinearFilter; // Suavização (Bilinear)
        this.fieldTexture.magFilter = THREE.LinearFilter;
        this.fieldTexture.generateMipmaps = false;
        this.fieldTexture.needsUpdate = true;
        
        // Vertex Shader
        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `;

        // Fragment Shader (Turbo-like Colormap)
        const fragmentShader = `
            uniform sampler2D uDataTexture;
            uniform float uOpacity;
            varying vec2 vUv;

            // Função de cor (Jet/Rainbow suavizado)
            vec3 colormap(float t) {
                float r = clamp(1.5 - abs(3.0 * t - 2.25), 0.0, 1.0);
                float g = clamp(1.5 - abs(3.0 * t - 1.5), 0.0, 1.0);
                float b = clamp(1.5 - abs(3.0 * t - 0.75), 0.0, 1.0);
                return vec3(r, g, b);
            }

            void main() {
                // Lê valor normalizado (0..1) da textura
                // 0.0 = -Max, 0.5 = 0, 1.0 = +Max
                float val = texture2D(uDataTexture, vUv).r;
                
                // Intensidade (distância do zero/0.5)
                float intensity = abs(val - 0.5) * 2.0;
                
                // Cor
                vec3 col = colormap(val);
                
                // Transparência baseada na intensidade (threshold suave)
                // Valores muito baixos ficam transparentes para não poluir a visão
                float alpha = smoothstep(0.05, 0.2, intensity) * uOpacity;
                
                // Boost na cor para ficar "brilhante" (emissive feel)
                gl_FragColor = vec4(col * (1.0 + intensity * 0.5), alpha);
            }
        `;
        
        // Material Shader
        const material = new THREE.ShaderMaterial({
            uniforms: {
                uDataTexture: { value: this.fieldTexture },
                uOpacity: { value: 0.85 }
            },
            vertexShader: vertexShader,
            fragmentShader: fragmentShader,
            transparent: true,
            side: THREE.DoubleSide,
            depthWrite: false,
            blending: THREE.AdditiveBlending // Brilho aditivo
        });
        
        this.fieldPlane = new THREE.Mesh(geometry, material);
        this.fieldPlane.position.y = 0;
        
        this.fieldGroup.add(this.fieldPlane);
        this.fieldGroup.visible = this.settings.showField3D;
        
        // Guardar referência para update
        this.fieldMaterial = material;
    }
    
    updateField3D(frame) {
        if (!this.fieldTexture || !frame || !frame.field) return;
        
        const field = frame.field;
        const width = this.fieldTexture.image.width;
        const height = this.fieldTexture.image.height;
        const data = this.fieldTexture.image.data;
        
        let ptr = 0;
        
        for (let z = 0; z < height; z++) {
            for (let x = 0; x < width; x++) {
                // Mapeia field value (-1..1) para byte (0..255)
                let val = 0;
                if (field[x] && typeof field[x][z] !== 'undefined') {
                    val = field[x][z];
                }
                
                // Clamp e conversão
                // -1 -> 0, 0 -> 127, 1 -> 255
                data[ptr++] = Math.floor((Math.max(-1, Math.min(1, val)) + 1) * 127.5);
            }
        }
        
        this.fieldTexture.needsUpdate = true;
    }
    
    generateColormap() {
        const colors = [];
        for (let i = 0; i < 256; i++) {
            const t = i / 255;
            let r, g, b;
            
            // Azul (negativo) -> Preto (zero) -> Vermelho (positivo)
            if (t < 0.5) {
                const s = t * 2; // 0..1
                r = 0;
                g = Math.floor(100 * s);
                b = Math.floor(255 * (1 - s * 0.5)); // Azul brilhante a escuro
            } else {
                const s = (t - 0.5) * 2; // 0..1
                r = Math.floor(255 * s); // Preto a vermelho brilhante
                g = Math.floor(100 * s);
                b = 0;
            }
            colors.push([r, g, b]);
        }
        return colors;
    }
    
    toggleField3D() {
        this.settings.showField3D = !this.settings.showField3D;
        this.fieldGroup.visible = this.settings.showField3D;
        return this.settings.showField3D;
    }
    
    // ========================================================================
    // CAMERA CONTROLS
    // ========================================================================
    
    fitCameraToObject() {
        const box = new THREE.Box3().setFromObject(this.antennaGroup);
        const size = box.getSize(new THREE.Vector3());
        const center = box.getCenter(new THREE.Vector3());
        
        const maxDim = Math.max(size.x, size.y, size.z);
        const fov = this.camera.fov * (Math.PI / 180);
        const distance = maxDim / (2 * Math.tan(fov / 2)) * 1.8;
        
        this.camera.position.set(
            center.x + distance * 0.7,
            center.y + distance * 0.5,
            center.z + distance * 0.7
        );
        
        this.controls.target.copy(center);
        this.controls.update();
    }
    
    resetCamera() {
        const { defaultPosition } = RENDER_CONFIG.camera;
        this.camera.position.set(defaultPosition.x, defaultPosition.y, defaultPosition.z);
        this.controls.target.set(0, 0, 0);
        this.controls.update();
    }
    
    setCameraView(view) {
        const d = 2.5;
        const views = {
            front: { x: 0, y: 0, z: d },
            back: { x: 0, y: 0, z: -d },
            top: { x: 0, y: d, z: 0.01 },
            bottom: { x: 0, y: -d, z: 0.01 },
            left: { x: -d, y: 0, z: 0 },
            right: { x: d, y: 0, z: 0 },
            iso: { x: d * 0.6, y: d * 0.4, z: d * 0.6 }
        };
        
        const pos = views[view] || views.iso;
        this.camera.position.set(pos.x, pos.y, pos.z);
        this.controls.update();
    }
    
    // ========================================================================
    // SETTINGS
    // ========================================================================
    
    toggleGrid() {
        this.settings.showGrid = !this.settings.showGrid;
        this.gridHelper.visible = this.settings.showGrid;
        return this.settings.showGrid;
    }
    
    toggleAxes() {
        this.settings.showAxes = !this.settings.showAxes;
        this.axesHelper.visible = this.settings.showAxes;
        return this.settings.showAxes;
    }
    
    toggleRadiation() {
        this.settings.showRadiation = !this.settings.showRadiation;
        
        if (this.settings.showRadiation && !this.particleSystem) {
            this.createRadiationParticles();
        } else if (!this.settings.showRadiation && this.particleSystem) {
            this.scene.remove(this.particleSystem);
            this.particleSystem = null;
        }
        
        return this.settings.showRadiation;
    }
    
    toggleAutoRotate() {
        this.settings.autoRotate = !this.settings.autoRotate;
        return this.settings.autoRotate;
    }
    
    setTheme(isDark) {
        if (!this.scene || !this.gridHelper) return;

        if (isDark) {
            this.scene.background = new THREE.Color(0x0a0a1a);
            this.scene.fog = new THREE.FogExp2(0x0a0a1a, 0.12);
            this.gridHelper.material.color.setHex(0x00ffff);
        } else {
            this.scene.background = new THREE.Color(0xf5f5fa);
            this.scene.fog = new THREE.FogExp2(0xf5f5fa, 0.08);
            this.gridHelper.material.color.setHex(0x3366ff);
        }
    }
    
    hideLoading() {
        const overlay = document.getElementById('viewport-loading');
        if (overlay) overlay.classList.add('hidden');
    }
    
    takeScreenshot() {
        if (!this.renderer || !this.scene || !this.camera) return null;
        this.renderer.render(this.scene, this.camera);
        return this.canvas.toDataURL('image/png');
    }
    
    dispose() {
        if (this.animationId) cancelAnimationFrame(this.animationId);
        this.clearAntenna();
        Object.values(this.materials).forEach(m => m.dispose());
        this.renderer.dispose();
        this.controls.dispose();
    }
}

// ============================================================================
// FIELD RENDERER
// ============================================================================

class FieldRenderer {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) return;
        
        this.ctx = this.canvas.getContext('2d');
        this.frames = [];
        this.currentFrame = 0;
        this.isPlaying = false;
        this.animationId = null;
        this.fieldShape = [0, 0];
        this.playbackSpeed = 1;
        
        this.colormap = this.generateColormap();
    }
    
    generateColormap() {
        const colors = [];
        for (let i = 0; i < 256; i++) {
            const t = i / 255;
            let r, g, b;
            
            if (t < 0.5) {
                const s = t * 2;
                r = Math.round(30 * s);
                g = Math.round(30 * s);
                b = Math.round(255 * (1 - s * 0.7));
            } else {
                const s = (t - 0.5) * 2;
                r = Math.round(255 * s);
                g = Math.round(50 * (1 - s));
                b = Math.round(50 * (1 - s));
            }
            colors.push([r, g, b]);
        }
        return colors;
    }
    
    setFrames(frames, fieldShape) {
        this.frames = frames || [];
        this.fieldShape = fieldShape || [0, 0];
        this.currentFrame = 0;
        if (this.frames.length > 0) this.renderFrame(0);
    }
    
    renderFrame(idx) {
        if (idx < 0 || idx >= this.frames.length) return;
        
        const frame = this.frames[idx];
        
        // Notifica listeners
        if (this.onFrameUpdate) {
            this.onFrameUpdate(frame);
        }
        
        const field = frame.field;
        const [nx, nz] = this.fieldShape;
        
        const width = this.canvas.width;
        const height = this.canvas.height;
        const imageData = this.ctx.createImageData(width, height);
        const data = imageData.data;
        
        const cellW = width / nx;
        const cellH = height / nz;
        
        for (let py = 0; py < height; py++) {
            for (let px = 0; px < width; px++) {
                const i = Math.floor(px / cellW);
                const j = Math.floor((height - 1 - py) / cellH);
                
                if (i >= 0 && i < nx && j >= 0 && j < nz && field[i]) {
                    const value = field[i][j] || 0;
                    const colorIdx = Math.max(0, Math.min(255, Math.floor((value + 1) / 2 * 255)));
                    const [r, g, b] = this.colormap[colorIdx];
                    const idx = (py * width + px) * 4;
                    data[idx] = r;
                    data[idx + 1] = g;
                    data[idx + 2] = b;
                    data[idx + 3] = 255;
                }
            }
        }
        
        this.ctx.putImageData(imageData, 0, 0);
        
        const timeEl = document.getElementById('animation-time');
        if (timeEl) timeEl.textContent = `${frame.time_ns.toFixed(2)} ns`;
        
        const slider = document.getElementById('animation-slider');
        if (slider && this.frames.length > 1) {
            slider.value = (idx / (this.frames.length - 1)) * 100;
        }
    }
    
    play() {
        if (!this.frames.length) return;
        this.isPlaying = true;
        this.animate();
        this.updateButton(true);
    }
    
    pause() {
        this.isPlaying = false;
        if (this.animationId) {
            clearTimeout(this.animationId);
            this.animationId = null;
        }
        this.updateButton(false);
    }
    
    toggle() {
        this.isPlaying ? this.pause() : this.play();
    }
    
    animate() {
        if (!this.isPlaying) return;
        this.renderFrame(this.currentFrame);
        this.currentFrame = (this.currentFrame + 1) % this.frames.length;
        this.animationId = setTimeout(() => this.animate(), 50 / this.playbackSpeed);
    }
    
    seekTo(pct) {
        this.currentFrame = Math.floor((pct / 100) * (this.frames.length - 1));
        this.renderFrame(this.currentFrame);
    }
    
    setSpeed(speed) {
        this.playbackSpeed = Math.max(0.25, Math.min(4, speed));
    }
    
    reset() {
        this.pause();
        this.currentFrame = 0;
        if (this.frames.length) this.renderFrame(0);
    }
    
    updateButton(playing) {
        const btn = document.getElementById('btn-play-pause');
        if (btn) btn.innerHTML = playing ? '<i class="fas fa-pause"></i>' : '<i class="fas fa-play"></i>';
    }
}

// ============================================================================
// EXPORT
// ============================================================================

window.AntennaRenderer = AntennaRenderer;
window.FieldRenderer = FieldRenderer;
