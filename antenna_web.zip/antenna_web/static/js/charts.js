/**
 * AntennaSim - Módulo de Gráficos Avançado
 * Chart.js + Canvas customizado para Smith Chart
 */

class ChartManager {
    constructor() {
        this.charts = {};
        this.smithCanvas = null;
        this.smithCtx = null;
        this.smithDims = null;
        this.currentData = { smith: null, radiation: null };
        
        this.colors = {
            primary: '#3b82f6',
            secondary: '#8b5cf6',
            success: '#10b981',
            warning: '#f59e0b',
            error: '#ef4444',
            grid: 'rgba(148, 163, 184, 0.15)',
            text: '#94a3b8',
            background: '#1e293b'
        };
        
        this.init();
    }
    
    init() {
        Chart.defaults.color = this.colors.text;
        Chart.defaults.borderColor = this.colors.grid;
        Chart.defaults.font.family = "'Inter', sans-serif";
        
        this.initSmithChart();
        this.initRadiationChart();
        this.initS11Chart();
        this.initVSWRChart();
        
        console.log('📊 ChartManager inicializado');
    }
    
    // ========================================================================
    // SMITH CHART (Canvas Custom)
    // ========================================================================
    
    initSmithChart() {
        this.smithCanvas = document.getElementById('chart-smith');
        if (!this.smithCanvas) return;
        
        this.smithCtx = this.smithCanvas.getContext('2d');
        this.drawSmithGrid();
    }
    
    drawSmithGrid() {
        const canvas = this.smithCanvas;
        const ctx = this.smithCtx;
        
        const dpr = window.devicePixelRatio || 1;
        const w = canvas.clientWidth;
        const h = canvas.clientHeight;
        
        canvas.width = w * dpr;
        canvas.height = h * dpr;
        ctx.scale(dpr, dpr);
        
        const cx = w / 2;
        const cy = h / 2;
        const radius = Math.min(w, h) / 2 - 15;
        
        // Background
        ctx.fillStyle = this.colors.background;
        ctx.fillRect(0, 0, w, h);
        
        ctx.strokeStyle = 'rgba(100, 116, 139, 0.25)';
        ctx.lineWidth = 0.5;
        
        // Resistance circles
        [0, 0.2, 0.5, 1, 2, 5].forEach(r => {
            const cr = radius / (1 + r);
            const ccx = cx + (r / (1 + r)) * radius;
            ctx.beginPath();
            ctx.arc(ccx, cy, cr, 0, Math.PI * 2);
            ctx.stroke();
        });
        
        // Reactance arcs
        [0.2, 0.5, 1, 2, 5].forEach(x => {
            const ar = radius / x;
            
            // Positive (top)
            ctx.beginPath();
            const startPos = Math.PI + Math.asin(Math.min(1, 1/x));
            ctx.arc(cx + radius, cy - ar, ar, startPos, Math.PI * 1.5);
            ctx.stroke();
            
            // Negative (bottom)
            ctx.beginPath();
            const endNeg = Math.PI - Math.asin(Math.min(1, 1/x));
            ctx.arc(cx + radius, cy + ar, ar, Math.PI * 0.5, endNeg);
            ctx.stroke();
        });
        
        // Outer circle
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.5)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.stroke();
        
        // Real axis
        ctx.beginPath();
        ctx.moveTo(cx - radius, cy);
        ctx.lineTo(cx + radius, cy);
        ctx.stroke();
        
        // Center (Z0)
        ctx.fillStyle = this.colors.success;
        ctx.beginPath();
        ctx.arc(cx, cy, 4, 0, Math.PI * 2);
        ctx.fill();
        
        this.smithDims = { cx, cy, radius };
    }
    
    updateSmithChart(data) {
        if (!this.smithCtx || !data) return;
        
        this.currentData.smith = data;
        this.drawSmithGrid();
        
        const ctx = this.smithCtx;
        const { cx, cy, radius } = this.smithDims;
        
        if (data.gamma_real && data.gamma_imag) {
            ctx.strokeStyle = this.colors.primary;
            ctx.lineWidth = 2;
            ctx.beginPath();
            
            let first = true;
            for (let i = 0; i < data.gamma_real.length; i++) {
                const x = cx + data.gamma_real[i] * radius;
                const y = cy - data.gamma_imag[i] * radius;
                
                if (first) {
                    ctx.moveTo(x, y);
                    first = false;
                } else {
                    ctx.lineTo(x, y);
                }
            }
            ctx.stroke();
            
            ctx.fillStyle = this.colors.success;
            ctx.beginPath();
            ctx.arc(cx + data.gamma_real[0] * radius, cy - data.gamma_imag[0] * radius, 4, 0, Math.PI * 2);
            ctx.fill();
            
            const last = data.gamma_real.length - 1;
            ctx.fillStyle = this.colors.error;
            ctx.beginPath();
            ctx.arc(cx + data.gamma_real[last] * radius, cy - data.gamma_imag[last] * radius, 4, 0, Math.PI * 2);
            ctx.fill();
            
            if (data.resonance) {
                const resFreq = data.resonance.frequency_mhz;
                const idx = data.frequencies_mhz.findIndex(f => Math.abs(f - resFreq) < 2);
                if (idx >= 0) {
                    ctx.fillStyle = this.colors.warning;
                    ctx.beginPath();
                    ctx.arc(cx + data.gamma_real[idx] * radius, cy - data.gamma_imag[idx] * radius, 6, 0, Math.PI * 2);
                    ctx.fill();
                    
                    ctx.fillStyle = '#fff';
                    ctx.font = '10px Inter';
                    ctx.fillText(`${resFreq.toFixed(0)} MHz`, cx + data.gamma_real[idx] * radius + 10, cy - data.gamma_imag[idx] * radius);
                }
            }
            
            if (data.best_match) {
                const bestFreq = data.best_match.frequency_mhz;
                const idxBest = data.frequencies_mhz.findIndex(f => Math.abs(f - bestFreq) < 2);
                if (idxBest >= 0) {
                    ctx.fillStyle = this.colors.secondary;
                    ctx.beginPath();
                    ctx.arc(cx + data.gamma_real[idxBest] * radius, cy - data.gamma_imag[idxBest] * radius, 5, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
            
            if (data.bandwidth && data.frequencies_mhz) {
                const bwMin = data.bandwidth.min_mhz;
                const bwMax = data.bandwidth.max_mhz;
                const idxMin = data.frequencies_mhz.findIndex(f => Math.abs(f - bwMin) < 2);
                const idxMax = data.frequencies_mhz.findIndex(f => Math.abs(f - bwMax) < 2);
                ctx.fillStyle = '#e5e7eb';
                ctx.font = '9px Inter';
                if (idxMin >= 0) {
                    const x = cx + data.gamma_real[idxMin] * radius;
                    const y = cy - data.gamma_imag[idxMin] * radius;
                    ctx.beginPath();
                    ctx.arc(x, y, 3, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillText('-10 dB', x + 6, y - 4);
                }
                if (idxMax >= 0) {
                    const x = cx + data.gamma_real[idxMax] * radius;
                    const y = cy - data.gamma_imag[idxMax] * radius;
                    ctx.beginPath();
                    ctx.arc(x, y, 3, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillText('-10 dB', x + 6, y - 4);
                }
            }
        }
        
        const vswrs = [1.5, 2, 3];
        ctx.setLineDash([4, 4]);
        vswrs.forEach((s, idx) => {
            const rGamma = ((s - 1) / (s + 1)) * radius;
            ctx.strokeStyle = idx === 1 ? this.colors.success : 'rgba(148, 163, 184, 0.5)';
            ctx.lineWidth = idx === 1 ? 1.2 : 0.8;
            ctx.beginPath();
            ctx.arc(cx, cy, rGamma, 0, Math.PI * 2);
            ctx.stroke();
            const tx = cx + rGamma + 4;
            const ty = cy - 4 - idx * 12;
            ctx.setLineDash([]);
            ctx.fillStyle = '#e5e7eb';
            ctx.font = '9px Inter';
            ctx.fillText(`VSWR=${s.toFixed(1)}`, tx, ty);
            ctx.setLineDash([4, 4]);
        });
        ctx.setLineDash([]);
    }
    
    // ========================================================================
    // RADIATION PATTERN (Polar Chart)
    // ========================================================================
    
    initRadiationChart() {
        const canvas = document.getElementById('chart-radiation');
        if (!canvas) return;
        
        this.charts.radiation = new Chart(canvas, {
            type: 'radar',
            data: {
                labels: this.generatePolarLabels(),
                datasets: [
                    {
                        label: 'Plano E',
                        data: new Array(37).fill(0),
                        borderColor: this.colors.primary,
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        pointRadius: 0,
                        borderWidth: 2
                    },
                    {
                        label: 'Plano H',
                        data: new Array(37).fill(0),
                        borderColor: this.colors.secondary,
                        backgroundColor: 'rgba(139, 92, 246, 0.1)',
                        pointRadius: 0,
                        borderWidth: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { boxWidth: 12, padding: 6, font: { size: 9 } }
                    }
                },
                scales: {
                    r: {
                        min: 0,
                        max: 1,
                        ticks: { stepSize: 0.25, font: { size: 8 }, backdropColor: 'transparent' },
                        grid: { color: this.colors.grid },
                        angleLines: { color: this.colors.grid },
                        pointLabels: { font: { size: 7 }, color: this.colors.text }
                    }
                }
            }
        });
    }
    
    generatePolarLabels() {
        const labels = [];
        for (let i = 0; i <= 360; i += 10) labels.push(i + '°');
        return labels;
    }
    
    updateRadiationChart(data) {
        if (!this.charts.radiation || !data) return;
        
        this.currentData.radiation = data;
        
        const resample = (arr) => {
            const result = [];
            for (let i = 0; i <= 360; i += 10) {
                const idx = Math.round(i / 360 * (arr.length - 1));
                result.push(arr[idx]);
            }
            return result;
        };
        
        this.charts.radiation.data.datasets[0].data = resample(data.pattern_e);
        this.charts.radiation.data.datasets[1].data = resample(data.pattern_h);
        this.charts.radiation.update();
    }

    updateAll(smithData, radiationData) {
        if (smithData) {
            this.updateSmithChart(smithData);
            this.updateS11Chart(smithData);
            this.updateVSWRChart(smithData);
        }
        if (radiationData) {
            this.updateRadiationChart(radiationData);
        }
    }
    
    // ========================================================================
    // S11 CHART
    // ========================================================================
    
    initS11Chart() {
        const canvas = document.getElementById('chart-s11');
        if (!canvas) return;
        
        this.charts.s11 = new Chart(canvas, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'S11',
                    data: [],
                    borderColor: this.colors.primary,
                    backgroundColor: 'rgba(59, 130, 246, 0.15)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0,
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { intersect: false, mode: 'index' },
                plugins: { legend: { display: false } },
                scales: {
                    x: {
                        title: { display: true, text: 'Freq (MHz)', font: { size: 9 } },
                        ticks: { font: { size: 8 }, maxTicksLimit: 6 },
                        grid: { color: this.colors.grid }
                    },
                    y: {
                        title: { display: true, text: 'S11 (dB)', font: { size: 9 } },
                        min: -40,
                        max: 0,
                        ticks: { font: { size: 8 } },
                        grid: { color: this.colors.grid }
                    }
                }
            }
        });
    }
    
    updateS11Chart(data) {
        if (!this.charts.s11 || !data) return;
        
        const step = Math.max(1, Math.floor(data.frequencies_mhz.length / 40));
        const labels = [], values = [];
        
        for (let i = 0; i < data.frequencies_mhz.length; i += step) {
            labels.push(data.frequencies_mhz[i].toFixed(0));
            values.push(data.s11_db[i]);
        }
        
        this.charts.s11.data.labels = labels;
        this.charts.s11.data.datasets[0].data = values;
        this.charts.s11.update();
    }
    
    // ========================================================================
    // VSWR CHART
    // ========================================================================
    
    initVSWRChart() {
        const canvas = document.getElementById('chart-vswr');
        if (!canvas) return;
        
        this.charts.vswr = new Chart(canvas, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'VSWR',
                    data: [],
                    borderColor: this.colors.secondary,
                    backgroundColor: 'rgba(139, 92, 246, 0.15)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0,
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { intersect: false, mode: 'index' },
                plugins: { legend: { display: false } },
                scales: {
                    x: {
                        title: { display: true, text: 'Freq (MHz)', font: { size: 9 } },
                        ticks: { font: { size: 8 }, maxTicksLimit: 6 },
                        grid: { color: this.colors.grid }
                    },
                    y: {
                        title: { display: true, text: 'VSWR', font: { size: 9 } },
                        min: 1,
                        max: 10,
                        ticks: { font: { size: 8 } },
                        grid: { color: this.colors.grid }
                    }
                }
            }
        });
    }
    
    updateVSWRChart(data) {
        if (!this.charts.vswr || !data) return;
        
        const step = Math.max(1, Math.floor(data.frequencies_mhz.length / 40));
        const labels = [], values = [];
        
        for (let i = 0; i < data.frequencies_mhz.length; i += step) {
            labels.push(data.frequencies_mhz[i].toFixed(0));
            values.push(Math.min(data.vswr[i], 10));
        }
        
        this.charts.vswr.data.labels = labels;
        this.charts.vswr.data.datasets[0].data = values;
        this.charts.vswr.update();
    }
    
    // ========================================================================
    // UPDATE ALL
    // ========================================================================
    
    updateAll(smithData, radiationData) {
        if (smithData) {
            this.updateSmithChart(smithData);
            this.updateS11Chart(smithData);
            this.updateVSWRChart(smithData);
        }
        if (radiationData) {
            this.updateRadiationChart(radiationData);
        }
    }
    
    // ========================================================================
    // MODAL CHARTS
    // ========================================================================
    
    showExpanded(type) {
        const modal = document.getElementById('modal-overlay');
        const modalCanvas = document.getElementById('modal-chart');
        const modalTitle = document.getElementById('modal-title');
        
        if (!modal || !modalCanvas) return;
        
        modal.classList.remove('hidden');
        
        if (this.charts.modal) {
            this.charts.modal.destroy();
            this.charts.modal = null;
        }
        
        const data = type === 'radiation' ? this.currentData.radiation : this.currentData.smith;
        if (!data) return;
        
        switch (type) {
            case 'smith':
                modalTitle.textContent = 'Carta de Smith';
                this.createExpandedSmith(modalCanvas, data);
                break;
            case 'radiation':
                modalTitle.textContent = 'Diagrama de Radiação';
                this.createExpandedRadiation(modalCanvas, data);
                break;
            case 's11':
                modalTitle.textContent = 'S11 (Return Loss)';
                this.createExpandedS11(modalCanvas, data);
                break;
            case 'vswr':
                modalTitle.textContent = 'VSWR';
                this.createExpandedVSWR(modalCanvas, data);
                break;
        }
    }
    
    createExpandedSmith(canvas, data) {
        const ctx = canvas.getContext('2d');
        const dpr = window.devicePixelRatio || 1;
        const w = canvas.clientWidth;
        const h = canvas.clientHeight;
        
        canvas.width = w * dpr;
        canvas.height = h * dpr;
        ctx.scale(dpr, dpr);
        
        const cx = w / 2;
        const cy = h / 2;
        const radius = Math.min(w, h) / 2 - 40;
        
        ctx.fillStyle = this.colors.background;
        ctx.fillRect(0, 0, w, h);
        
        ctx.strokeStyle = 'rgba(100, 116, 139, 0.3)';
        ctx.lineWidth = 1;
        
        [0, 0.2, 0.5, 1, 2, 5].forEach(r => {
            const cr = radius / (1 + r);
            const ccx = cx + (r / (1 + r)) * radius;
            ctx.beginPath();
            ctx.arc(ccx, cy, cr, 0, Math.PI * 2);
            ctx.stroke();
            
            ctx.fillStyle = '#64748b';
            ctx.font = '11px Inter';
            ctx.fillText(r.toString(), ccx + cr + 4, cy + 4);
        });
        
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.6)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(cx - radius, cy);
        ctx.lineTo(cx + radius, cy);
        ctx.stroke();
        
        if (data.gamma_real) {
            ctx.strokeStyle = this.colors.primary;
            ctx.lineWidth = 3;
            ctx.beginPath();
            
            let first = true;
            for (let i = 0; i < data.gamma_real.length; i++) {
                const x = cx + data.gamma_real[i] * radius;
                const y = cy - data.gamma_imag[i] * radius;
                first ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
                first = false;
            }
            ctx.stroke();
            
            const firstX = cx + data.gamma_real[0] * radius;
            const firstY = cy - data.gamma_imag[0] * radius;
            ctx.fillStyle = this.colors.success;
            ctx.beginPath();
            ctx.arc(firstX, firstY, 5, 0, Math.PI * 2);
            ctx.fill();
            
            const last = data.gamma_real.length - 1;
            const lastX = cx + data.gamma_real[last] * radius;
            const lastY = cy - data.gamma_imag[last] * radius;
            ctx.fillStyle = this.colors.error;
            ctx.beginPath();
            ctx.arc(lastX, lastY, 5, 0, Math.PI * 2);
            ctx.fill();
            
            if (data.resonance) {
                const resFreq = data.resonance.frequency_mhz;
                const idx = data.frequencies_mhz.findIndex(f => Math.abs(f - resFreq) < 2);
                if (idx >= 0) {
                    const x = cx + data.gamma_real[idx] * radius;
                    const y = cy - data.gamma_imag[idx] * radius;
                    ctx.fillStyle = this.colors.warning;
                    ctx.beginPath();
                    ctx.arc(x, y, 7, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
        }
        
        ctx.fillStyle = this.colors.success;
        ctx.beginPath();
        ctx.arc(cx, cy, 6, 0, Math.PI * 2);
        ctx.fill();

        const vswrs = [1.5, 2, 3];
        ctx.setLineDash([4, 4]);
        vswrs.forEach((s, idx) => {
            const rGamma = ((s - 1) / (s + 1)) * radius;
            ctx.strokeStyle = idx === 1 ? this.colors.success : 'rgba(148, 163, 184, 0.5)';
            ctx.lineWidth = idx === 1 ? 1.2 : 0.8;
            ctx.beginPath();
            ctx.arc(cx, cy, rGamma, 0, Math.PI * 2);
            ctx.stroke();
        });
        ctx.setLineDash([]);

        ctx.fillStyle = '#e5e7eb';
        ctx.font = '11px Inter';
        let ty = 24;
        if (data.z0) {
            ctx.fillText(`Z0 = ${data.z0.toFixed ? data.z0.toFixed(1) : data.z0} Ω`, 16, ty);
            ty += 14;
        }
        if (data.resonance) {
            ctx.fillText(`fc ≈ ${data.resonance.frequency_mhz.toFixed(1)} MHz`, 16, ty);
            ty += 14;
            ctx.fillText(`Zin(fc) = ${data.resonance.impedance} Ω`, 16, ty);
            ty += 14;
            ctx.fillText(`S11(fc) = ${data.resonance.s11_db.toFixed(1)} dB`, 16, ty);
            ty += 14;
            ctx.fillText(`VSWR(fc) = ${data.resonance.vswr.toFixed(2)}`, 16, ty);
            ty += 14;
        }
        if (data.bandwidth) {
            ctx.fillText(`BW(-10 dB) = ${data.bandwidth.width_mhz.toFixed(1)} MHz`, 16, ty);
            ty += 14;
            ctx.fillText(`Faixa: ${data.bandwidth.min_mhz.toFixed(0)}–${data.bandwidth.max_mhz.toFixed(0)} MHz`, 16, ty);
        }
    }
    
    createExpandedRadiation(canvas, data) {
        const resample = (arr) => {
            const result = [];
            for (let i = 0; i <= 360; i += 10) {
                const idx = Math.round(i / 360 * (arr.length - 1));
                result.push(arr[idx]);
            }
            return result;
        };
        
        this.charts.modal = new Chart(canvas, {
            type: 'radar',
            data: {
                labels: this.generatePolarLabels(),
                datasets: [
                    {
                        label: 'Plano E',
                        data: resample(data.pattern_e),
                        borderColor: this.colors.primary,
                        backgroundColor: 'rgba(59, 130, 246, 0.2)',
                        pointRadius: 1,
                        borderWidth: 2
                    },
                    {
                        label: 'Plano H',
                        data: resample(data.pattern_h),
                        borderColor: this.colors.secondary,
                        backgroundColor: 'rgba(139, 92, 246, 0.2)',
                        pointRadius: 1,
                        borderWidth: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'top' } },
                scales: { r: { min: 0, max: 1, ticks: { stepSize: 0.2 } } }
            }
        });
    }
    
    createExpandedS11(canvas, data) {
        this.charts.modal = new Chart(canvas, {
            type: 'line',
            data: {
                labels: data.frequencies_mhz.map(f => f.toFixed(0)),
                datasets: [{
                    label: 'S11 (dB)',
                    data: data.s11_db,
                    borderColor: this.colors.primary,
                    backgroundColor: 'rgba(59, 130, 246, 0.2)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { title: { display: true, text: 'Frequência (MHz)' } },
                    y: { title: { display: true, text: 'S11 (dB)' }, min: -40, max: 0 }
                }
            }
        });
    }
    
    createExpandedVSWR(canvas, data) {
        this.charts.modal = new Chart(canvas, {
            type: 'line',
            data: {
                labels: data.frequencies_mhz.map(f => f.toFixed(0)),
                datasets: [{
                    label: 'VSWR',
                    data: data.vswr.map(v => Math.min(v, 10)),
                    borderColor: this.colors.secondary,
                    backgroundColor: 'rgba(139, 92, 246, 0.2)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { title: { display: true, text: 'Frequência (MHz)' } },
                    y: { title: { display: true, text: 'VSWR' }, min: 1, max: 10 }
                }
            }
        });
    }
    
    closeModal() {
        const modal = document.getElementById('modal-overlay');
        if (modal) modal.classList.add('hidden');
        
        if (this.charts.modal) {
            this.charts.modal.destroy();
            this.charts.modal = null;
        }
    }
    
    resize() {
        Object.values(this.charts).forEach(chart => {
            if (chart && chart.resize) chart.resize();
        });
        
        if (this.currentData.smith) {
            this.updateSmithChart(this.currentData.smith);
        } else if (this.smithCanvas) {
            this.drawSmithGrid();
        }
    }
}

window.ChartManager = ChartManager;
