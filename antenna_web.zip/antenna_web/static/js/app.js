/**
 * AntennaSim - Aplicação Principal
 * Gerenciamento de estado, API e interações
 */

class AntennaSim {
    constructor() {
        this.state = {
            antennaType: 'dipole',
            frequency: 300e6,
            length: null,
            radius: 0.001,
            numDirectors: 3,
            substrateEr: 4.4,
            turns: 5,
            loopRadius: null,
            
            // Horn
            hornWidth: null,
            hornHeight: null,
            hornLength: null,
            
            // Dish
            dishDiameter: null,
            dishFocal: null,
            
            // LPDA
            lpdaTau: 0.86,
            lpdaSigma: 0.15,
            
            cellsPerWavelength: 20,
            numSteps: 200,
            sourceType: 'gaussian',
            courant: 0.99,
            pmlLayers: 8,
            useOptimized: true,
            
            isDarkMode: true,
            simulationId: null
        };
        
        this.data = {
            antenna: null,
            smith: null,
            radiation: null,
            parameters: null,
            simulation: null
        };
        
        this.renderer = null;
        this.fieldRenderer = null;
        this.chartManager = null;
        
        this.init();
    }
    
    init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }
    }
    
    setup() {
        console.log('🚀 AntennaSim iniciando...');
        
        this.renderer = new AntennaRenderer('canvas-3d');
        this.fieldRenderer = new FieldRenderer('canvas-field');
            this.chartManager = new ChartManager();
        
        // Connect renderers for 3D field visualization
        this.fieldRenderer.onFrameUpdate = (frame) => {
            if (this.renderer) this.renderer.updateField3D(frame);
        };
        
        this.bindEvents();
        this.applyTheme();
        this.createAntenna();
        
        console.log('✅ AntennaSim pronto!');

        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/service-worker.js').catch(err => {
                console.error('Service worker registration failed', err);
            });
        }
    }
    
    // ========================================================================
    // EVENT BINDING
    // ========================================================================
    
    bindEvents() {
        // Antenna 3D Interaction
        const canvas3d = document.getElementById('canvas-3d');
        if (canvas3d) {
            canvas3d.addEventListener('antenna-click', () => {
                console.log('📡 Clique na antena detectado: Atualizando análise...');
                this.showToast('Atualizando análise da antena...', 'info');
                this.fetchAnalysis();
            });
        }

        // Antenna type
        document.querySelectorAll('.antenna-type-btn').forEach(btn => {
            btn.addEventListener('click', () => this.setAntennaType(btn.dataset.type));
        });
        
        // Frequency
        const freqInput = document.getElementById('input-frequency');
        if (freqInput) {
            freqInput.addEventListener('change', (e) => {
                this.state.frequency = parseFloat(e.target.value) * 1e6;
                this.updateWavelength();
                this.createAntenna();
            });
        }
        
        // Auto length
        const autoLength = document.getElementById('auto-length');
        if (autoLength) {
            autoLength.addEventListener('change', (e) => {
                const lengthInput = document.getElementById('input-length');
                if (lengthInput) {
                    lengthInput.disabled = e.target.checked;
                    if (e.target.checked) {
                        this.state.length = null;
                        this.createAntenna();
                    }
                }
            });
        }
        
        // Length
        const lengthInput = document.getElementById('input-length');
        if (lengthInput) {
            lengthInput.addEventListener('change', (e) => {
                this.state.length = parseFloat(e.target.value) || null;
                this.createAntenna();
            });
        }

        // Optimize button
        document.getElementById('btn-optimize')?.addEventListener('click', () => this.optimizeLength());
        
        // Radius
        const radiusInput = document.getElementById('input-radius');
        if (radiusInput) {
            radiusInput.addEventListener('change', (e) => {
                this.state.radius = parseFloat(e.target.value) / 1000;
                this.createAntenna();
            });
        }
        
        // Sliders
        this.bindSlider('input-directors', 'directors-value', (val) => {
            this.state.numDirectors = parseInt(val);
        }, () => this.createAntenna());
        
        this.bindSlider('input-turns', 'turns-value', (val) => {
            this.state.turns = parseInt(val);
        }, () => this.createAntenna());
        
        // Horn Params
        ['input-horn-width', 'input-horn-height'].forEach(id => {
            document.getElementById(id)?.addEventListener('change', (e) => {
                const prop = id === 'input-horn-width' ? 'hornWidth' : 'hornHeight';
                this.state[prop] = parseFloat(e.target.value) || null;
                this.createAntenna();
            });
        });
        
        // Dish Params
        ['input-dish-diameter', 'input-dish-focal'].forEach(id => {
            document.getElementById(id)?.addEventListener('change', (e) => {
                const prop = id === 'input-dish-diameter' ? 'dishDiameter' : 'dishFocal';
                this.state[prop] = parseFloat(e.target.value) || null;
                this.createAntenna();
            });
        });
        
        // LPDA Params
        ['input-lpda-tau', 'input-lpda-sigma'].forEach(id => {
            document.getElementById(id)?.addEventListener('change', (e) => {
                const prop = id === 'input-lpda-tau' ? 'lpdaTau' : 'lpdaSigma';
                this.state[prop] = parseFloat(e.target.value);
                this.createAntenna();
            });
        });
        
        // Loop Params
        const loopRadiusInput = document.getElementById('input-loop-radius');
        if (loopRadiusInput) {
            loopRadiusInput.addEventListener('change', (e) => {
                this.state.loopRadius = parseFloat(e.target.value) || null;
                this.createAntenna();
            });
        }
        
        this.bindSlider('input-resolution', 'resolution-value', (val) => {
            this.state.cellsPerWavelength = parseInt(val);
        });
        
        this.bindSlider('input-steps', 'steps-value', (val) => {
            this.state.numSteps = parseInt(val);
        });
        
        // Source type
        const sourceType = document.getElementById('input-source-type');
        if (sourceType) {
            sourceType.addEventListener('change', (e) => {
                this.state.sourceType = e.target.value;
            });
        }
        
        // Substrate
        const substrate = document.getElementById('input-substrate');
        if (substrate) {
            substrate.addEventListener('change', (e) => {
                this.state.substrateEr = parseFloat(e.target.value);
                this.createAntenna();
            });
        }
        
        // Simulate button
        const simBtn = document.getElementById('btn-simulate');
        if (simBtn) {
            simBtn.addEventListener('click', () => this.runSimulation());
        }
        
        // Viewport controls
        document.getElementById('btn-reset-camera')?.addEventListener('click', () => this.renderer.resetCamera());
        document.getElementById('btn-toggle-field3d')?.addEventListener('click', (e) => {
            const active = this.renderer.toggleField3D();
            e.currentTarget.classList.toggle('active', active);
        });
        document.getElementById('btn-toggle-grid')?.addEventListener('click', () => this.renderer.toggleGrid());
        document.getElementById('btn-toggle-axes')?.addEventListener('click', () => this.renderer.toggleAxes());
        document.getElementById('btn-toggle-radiation')?.addEventListener('click', () => this.renderer.toggleRadiation());
        document.getElementById('btn-auto-rotate')?.addEventListener('click', () => this.renderer.toggleAutoRotate());
        
        document.getElementById('btn-fullscreen')?.addEventListener('click', () => {
            const viewport = document.getElementById('viewport-3d');
            if (!document.fullscreenElement) {
                viewport.requestFullscreen();
            } else {
                document.exitFullscreen();
            }
        });
        
        // Theme
        document.getElementById('btn-theme')?.addEventListener('click', () => {
            this.state.isDarkMode = !this.state.isDarkMode;
            this.applyTheme();
        });
        
        // Help
        document.getElementById('btn-help')?.addEventListener('click', () => {
            document.getElementById('help-overlay')?.classList.remove('hidden');
        });
        document.getElementById('btn-close-help')?.addEventListener('click', () => {
            document.getElementById('help-overlay')?.classList.add('hidden');
        });

        // Matching Modal
        document.getElementById('btn-open-matching')?.addEventListener('click', () => this.calculateMatching());
        document.getElementById('btn-close-matching')?.addEventListener('click', () => {
            document.getElementById('matching-overlay')?.classList.add('hidden');
        });

        // Settings
        document.getElementById('btn-settings')?.addEventListener('click', () => {
            document.getElementById('settings-overlay')?.classList.remove('hidden');
            // Carrega valores atuais
            const courantInput = document.getElementById('setting-courant');
            const pmlInput = document.getElementById('setting-pml');
            const optimizedInput = document.getElementById('setting-optimized');
            if (courantInput) courantInput.value = this.state.courant;
            if (pmlInput) pmlInput.value = this.state.pmlLayers;
            if (optimizedInput) optimizedInput.checked = this.state.useOptimized;
        });
        
        document.getElementById('btn-close-settings')?.addEventListener('click', () => {
            document.getElementById('settings-overlay')?.classList.add('hidden');
        });

        document.getElementById('btn-save-settings')?.addEventListener('click', () => {
            const courantInput = document.getElementById('setting-courant');
            const pmlInput = document.getElementById('setting-pml');
            const optimizedInput = document.getElementById('setting-optimized');
            
            if (courantInput) this.state.courant = Math.min(parseFloat(courantInput.value), 1.0);
            if (pmlInput) this.state.pmlLayers = Math.max(parseInt(pmlInput.value), 4);
            if (optimizedInput) this.state.useOptimized = optimizedInput.checked;
            
            document.getElementById('settings-overlay')?.classList.add('hidden');
            this.showToast('Configurações salvas!', 'success');
        });
        
        // Modal
        document.getElementById('btn-close-modal')?.addEventListener('click', () => this.chartManager.closeModal());
        document.getElementById('modal-overlay')?.addEventListener('click', (e) => {
            if (e.target.id === 'modal-overlay') this.chartManager.closeModal();
        });
        
        // Chart expand buttons
        document.getElementById('btn-expand-smith')?.addEventListener('click', () => this.chartManager.showExpanded('smith'));
        document.getElementById('btn-expand-radiation')?.addEventListener('click', () => this.chartManager.showExpanded('radiation'));
        document.getElementById('btn-expand-s11')?.addEventListener('click', () => this.chartManager.showExpanded('s11'));
        document.getElementById('btn-expand-vswr')?.addEventListener('click', () => this.chartManager.showExpanded('vswr'));
        
        // Results tabs
        document.querySelectorAll('.results-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.results-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.results-content').forEach(c => c.classList.add('hidden'));
                tab.classList.add('active');
                document.getElementById(`results-${tab.dataset.results}`)?.classList.remove('hidden');
            });
        });
        
        // Animation controls
        document.getElementById('btn-play-pause')?.addEventListener('click', () => this.fieldRenderer.toggle());
        document.getElementById('animation-slider')?.addEventListener('input', (e) => {
            this.fieldRenderer.seekTo(parseFloat(e.target.value));
        });
        
        // Keyboard
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.chartManager.closeModal();
                document.getElementById('help-overlay')?.classList.add('hidden');
            }
        });
        
        // Resize
        window.addEventListener('resize', () => this.chartManager.resize());
    }

    switchTab(tab) {
        // Active State
        document.querySelectorAll('.nav-tab').forEach(t => {
            t.classList.toggle('active', t.dataset.tab === tab);
        });
        
        const show = (id) => document.getElementById(id)?.classList.remove('hidden');
        const hide = (id) => document.getElementById(id)?.classList.add('hidden');
        
        // Hide all toggleable panels
        ['panel-design-types', 'panel-design-params', 'panel-simulation', 
         'charts-panel', 'panel-results-text', 'panel-animation'].forEach(hide);
         
        const viewport = document.getElementById('viewport-3d');
        const resultsPanel = document.getElementById('results-panel');
        const sidebar = document.querySelector('.sidebar');
        
        // Reset visibility defaults
        if (viewport) viewport.style.display = '';
        if (resultsPanel) resultsPanel.classList.remove('hidden');
        if (sidebar) sidebar.classList.remove('hidden');

        switch(tab) {
            case 'design':
                show('panel-design-types');
                show('panel-design-params');
                if (resultsPanel) resultsPanel.classList.add('hidden');
                break;
                
            case 'simulation':
                show('panel-simulation');
                show('panel-animation');
                break;
                
            case 'analysis':
                show('charts-panel');
                show('panel-results-text');
                if (viewport) viewport.style.display = 'none';
                if (sidebar) sidebar.classList.add('hidden');
                break;
        }
        
        // Handle Resizing
        if (tab === 'analysis') {
            setTimeout(() => this.chartManager?.resize(), 50);
        } else {
            setTimeout(() => this.renderer?.onResize(), 50);
        }
    }
    
    bindSlider(inputId, valueId, onInput, onChange) {
        const input = document.getElementById(inputId);
        const value = document.getElementById(valueId);
        
        if (input) {
            input.addEventListener('input', (e) => {
                if (value) value.textContent = e.target.value;
                if (onInput) onInput(e.target.value);
            });
            
            if (onChange) {
                input.addEventListener('change', onChange);
            }
        }
    }
    
    // ========================================================================
    // ANTENNA TYPE
    // ========================================================================
    
    setAntennaType(type) {
        this.state.antennaType = type;
        
        document.querySelectorAll('.antenna-type-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.type === type);
        });
        
        const groups = {
            length: ['dipole', 'v_dipole', 'folded_dipole', 'monopole'],
            radius: ['dipole', 'v_dipole', 'folded_dipole', 'monopole', 'yagi', 'helix', 'loop'],
            directors: ['yagi'],
            substrate: ['patch'],
            turns: ['helix'],
            horn: ['horn'],
            dish: ['dish'],
            lpda: ['lpda'],
            loop: ['loop']
        };
        
        Object.entries(groups).forEach(([group, types]) => {
            const el = document.getElementById(`group-${group}`);
            if (el) el.classList.toggle('hidden', !types.includes(type));
        });
        
        document.getElementById('info-type').textContent = this.getTypeName(type);
        this.createAntenna();
    }
    
    getTypeName(type) {
        return {
            dipole: 'Dipolo',
            v_dipole: 'Dipolo em V',
            folded_dipole: 'Dipolo Dobrado',
            monopole: 'Monopolo',
            yagi: 'Yagi-Uda',
            patch: 'Patch',
            helix: 'Helicoidal',
            horn: 'Corneta',
            dish: 'Parabólica',
            lpda: 'Log-Periódica',
            loop: 'Loop'
        }[type] || type;
    }
    
    updateWavelength() {
        const wavelength = 299792458 / this.state.frequency;
        document.getElementById('calc-wavelength').textContent = `λ = ${(wavelength * 100).toFixed(2)} cm`;
        document.getElementById('info-freq').textContent = `${(this.state.frequency / 1e6).toFixed(0)} MHz`;
    }
    
    // ========================================================================
    // API CALLS
    // ========================================================================
    
    async createAntenna() {
        try {
            const response = await fetch('/api/antenna/create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    type: this.state.antennaType,
                    frequency: this.state.frequency,
                    length: this.state.length,
                    radius: this.state.radius,
                    num_directors: this.state.numDirectors,
                    substrate_er: this.state.substrateEr,
                    turns: this.state.turns,
                    // Horn
                    aperture_width: this.state.hornWidth,
                    aperture_height: this.state.hornHeight,
                    flare_length: this.state.hornLength,
                    // Dish
                    dish_diameter: this.state.dishDiameter,
                    focal_length: this.state.dishFocal,
                    // LPDA
                    tau: this.state.lpdaTau,
                    sigma: this.state.lpdaSigma,
                    // Loop
                    loop_radius: this.state.loopRadius
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.data.antenna = result.data;
                this.renderer.renderAntenna(this.data.antenna);
                this.updateInfoPanel();
                await this.fetchAnalysis();
            } else {
                this.showToast('Erro: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('Erro:', error);
            this.showToast('Erro de conexão', 'error');
        }
    }
    
    async fetchAnalysis() {
        try {
            // Smith Chart
            const smithRes = await fetch('/api/smith-chart', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    type: this.state.antennaType,
                    frequency: this.state.frequency,
                    length: this.state.length,
                    num_directors: this.state.numDirectors
                })
            });
            
            const smithData = await smithRes.json();
            if (smithData.success) {
                this.data.smith = smithData.data;
                this.updateResultsFromSmith();
            }
            
            // Radiation pattern
            const radRes = await fetch('/api/radiation-pattern', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    type: this.state.antennaType,
                    frequency: this.state.frequency,
                    num_directors: this.state.numDirectors,
                    turns: this.state.turns
                })
            });
            
            const radData = await radRes.json();
            if (radData.success) {
                this.data.radiation = radData.data;
                this.updateResultsFromRadiation();
            }
            
            const directivity = this.data.radiation && typeof this.data.radiation.directivity_db === 'number'
                ? this.data.radiation.directivity_db
                : null;
            
            const paramsRes = await fetch('/api/calculate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    frequency: this.state.frequency,
                    directivity_db: directivity
                })
            });
            
            const paramsData = await paramsRes.json();
            if (paramsData.success) {
                this.data.parameters = paramsData.data;
                this.updateParametersPanel();
            }
            
            this.chartManager.updateAll(this.data.smith, this.data.radiation);
            
        } catch (error) {
            console.error('Erro na análise:', error);
        }
    }
    
    async runSimulation() {
        const btn = document.getElementById('btn-simulate');
        const progress = document.getElementById('simulation-progress');
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Simulando...';
        progress.classList.remove('hidden');
        
        try {
            const startRes = await fetch('/api/simulation/start', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    antenna_type: this.state.antennaType,
                    frequency: this.state.frequency,
                    length: this.state.length,
                    radius: this.state.radius,
                    num_directors: this.state.numDirectors,
                    substrate_er: this.state.substrateEr,
                    turns: this.state.turns,
                    // Horn
                    aperture_width: this.state.hornWidth,
                    aperture_height: this.state.hornHeight,
                    flare_length: this.state.hornLength,
                    // Dish
                    dish_diameter: this.state.dishDiameter,
                    focal_length: this.state.dishFocal,
                    // LPDA
                    tau: this.state.lpdaTau,
                    sigma: this.state.lpdaSigma,
                    
                    cells_per_wavelength: this.state.cellsPerWavelength,
                    num_steps: this.state.numSteps,
                    source_type: this.state.sourceType,
                    courant: this.state.courant,
                    pml_layers: this.state.pmlLayers,
                    use_optimized: this.state.useOptimized
                })
            });
            
            const startData = await startRes.json();
            if (!startData.success) throw new Error(startData.error);
            
            this.state.simulationId = startData.simulation_id;
            
            // Poll status
            let completed = false;
            while (!completed) {
                await this.sleep(500);
                
                const statusRes = await fetch(`/api/simulation/${this.state.simulationId}/status`);
                const statusData = await statusRes.json();
                
                if (!statusData.success) throw new Error(statusData.error);
                
                const sim = statusData.data;
                progressFill.style.width = `${sim.progress}%`;
                progressText.textContent = `${sim.progress}%`;
                
                if (sim.status === 'completed') {
                    completed = true;
                    this.data.simulation = sim;
                    
                    const framesRes = await fetch(`/api/simulation/${this.state.simulationId}/frames`);
                    const framesData = await framesRes.json();
                    
                    if (framesData.success) {
                        // Configura visualização 3D do campo
                        if (this.data.simulation && this.data.simulation.grid) {
                            const grid = this.data.simulation.grid;
                            const gridInfo = {
                                nx: framesData.field_shape[0],
                                nz: framesData.field_shape[1],
                                dx: grid.dx
                            };
                            const scale = this.renderer && typeof this.renderer.antennaScale === 'number'
                                ? this.renderer.antennaScale
                                : 1.0;
                            this.renderer.setupFieldVisualization(gridInfo, scale);
                        }

                        this.fieldRenderer.setFrames(framesData.frames, framesData.field_shape);
                        
                        // Inicia animação automaticamente se houver frames
                        if (framesData.frames.length > 0) {
                            this.fieldRenderer.play();
                        }
                    }
                    
                    this.showToast('Simulação concluída!', 'success');
                } else if (sim.status === 'error') {
                    throw new Error(sim.error || 'Erro na simulação');
                }
            }
            
        } catch (error) {
            console.error('Erro:', error);
            this.showToast('Erro: ' + error.message, 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-play"></i> Iniciar Simulação';
            setTimeout(() => progress.classList.add('hidden'), 2000);
        }
    }
    
    async optimizeLength() {
        const btn = document.getElementById('btn-optimize');
        const status = document.getElementById('optimization-status');
        const msg = document.getElementById('opt-message');
        const progress = document.getElementById('opt-progress');
        const progressFill = document.getElementById('opt-progress-fill');
        
        btn.disabled = true;
        status.classList.remove('hidden');
        msg.textContent = 'Iniciando otimização...';
        progress.textContent = '0%';
        progressFill.style.width = '0%';
        
        try {
            const response = await fetch('/api/optimize', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    antenna_type: this.state.antennaType,
                    target_freq: this.state.frequency,
                    start_length: this.state.length,
                    radius: this.state.radius
                })
            });
            
            const data = await response.json();
            if (!data.id) throw new Error('ID de otimização não retornado');
            
            const optId = data.id;
            
            // Poll status
            let completed = false;
            while (!completed) {
                await this.sleep(1000);
                
                const statusRes = await fetch(`/api/optimize/${optId}/status`);
                const state = await statusRes.json();
                
                msg.textContent = state.message;
                const pct = Math.round(state.progress);
                progress.textContent = `${pct}%`;
                progressFill.style.width = `${pct}%`;
                
                if (state.status === 'completed') {
                    completed = true;
                    if (state.result && state.result.optimized_length) {
                        this.state.length = state.result.optimized_length;
                        
                        const inputLen = document.getElementById('input-length');
                        const autoLen = document.getElementById('auto-length');
                        
                        if (inputLen) {
                            inputLen.value = this.state.length.toFixed(4);
                            inputLen.disabled = false;
                        }
                        if (autoLen) {
                            autoLen.checked = false;
                        }
                        
                        // Atualiza visualização
                        this.createAntenna();
                        
                        this.showToast(`Otimizado! Novo comprimento: ${this.state.length.toFixed(4)}m (VSWR: ${state.result.final_vswr.toFixed(2)})`, 'success');
                        
                        // Executa simulação completa para atualizar gráficos
                        // Opcional: Perguntar ao usuário? Ou rodar direto?
                        // Vamos apenas atualizar a geometria por enquanto.
                    }
                } else if (state.status === 'error') {
                    throw new Error(state.message);
                }
            }
        } catch (error) {
            console.error('Erro na otimização:', error);
            this.showToast('Erro na otimização: ' + error.message, 'error');
            msg.textContent = 'Erro: ' + error.message;
        } finally {
            btn.disabled = false;
            // Mantém status visível por um tempo ou adiciona botão de fechar?
            // Vamos esconder após sucesso, manter se erro?
            // Por simplicidade, esconde após 3s se sucesso.
            if (!msg.textContent.includes('Erro')) {
                setTimeout(() => status.classList.add('hidden'), 5000);
            }
        }
    }

    // ========================================================================
    // UI UPDATES
    // ========================================================================
    
    updateInfoPanel() {
        if (!this.data.antenna) return;
        
        const bb = this.data.antenna.bounding_box;
        const maxDim = Math.max(bb.size[0], bb.size[1], bb.size[2]);
        document.getElementById('info-length').textContent = `${(maxDim * 100).toFixed(1)} cm`;
        
        this.updateWavelength();
        this.updateParametersPanel();
    }
    
    updateResultsFromSmith() {
        if (!this.data.smith) return;
        
        const { resonance, bandwidth } = this.data.smith;
        
        document.getElementById('result-z').textContent = resonance.impedance + ' Ω';
        document.getElementById('result-s11').textContent = resonance.s11_db.toFixed(1) + ' dB';
        document.getElementById('result-vswr').textContent = resonance.vswr.toFixed(2) + ':1';
        
        const gamma = (resonance.vswr - 1) / (resonance.vswr + 1);
        document.getElementById('result-gamma').textContent = gamma.toFixed(3);
        
        document.getElementById('info-impedance').textContent = resonance.impedance.split('+')[0].trim() + ' Ω';
        
        document.getElementById('result-fc').textContent = resonance.frequency_mhz.toFixed(1) + ' MHz';
        document.getElementById('result-bw').textContent = bandwidth.width_mhz.toFixed(1) + ' MHz';
        document.getElementById('result-bw-pct').textContent = bandwidth.percent.toFixed(1) + '%';
        document.getElementById('result-range').textContent = `${bandwidth.min_mhz.toFixed(0)} - ${bandwidth.max_mhz.toFixed(0)} MHz`;
    }
    
    updateResultsFromRadiation() {
        if (!this.data.radiation) return;
        
        document.getElementById('result-directivity').textContent = this.data.radiation.directivity_db.toFixed(2) + ' dBi';
        if (this.data.parameters && typeof this.data.parameters.gain_db === 'number') {
            document.getElementById('result-gain').textContent = this.data.parameters.gain_db.toFixed(2) + ' dBi';
        } else {
            document.getElementById('result-gain').textContent = (this.data.radiation.directivity_db - 0.5).toFixed(1) + ' dBi';
        }
        document.getElementById('result-beamwidth').textContent = this.data.radiation['3db_beamwidth'].toFixed(0) + '°';
        document.getElementById('result-polarization').textContent = this.state.antennaType === 'helix' ? 'Circular' : 'Linear';
        
        // Passa dados 3D para o renderer
        if (this.data.radiation.pattern_3d && this.renderer) {
            this.renderer.setRadiationData(this.data.radiation.pattern_3d);
        }
    }
    
    updateParametersPanel() {
        if (!this.data.parameters) return;
        
        const dirEl = document.getElementById('info-directivity');
        const gainEl = document.getElementById('info-gain');
        
        if (dirEl && typeof this.data.parameters.directivity_db === 'number') {
            dirEl.textContent = `${this.data.parameters.directivity_db.toFixed(2)} dBi`;
        }
        
        if (gainEl && typeof this.data.parameters.gain_db === 'number') {
            gainEl.textContent = `${this.data.parameters.gain_db.toFixed(2)} dBi`;
        }
    }
    
    applyTheme() {
        document.documentElement.setAttribute('data-theme', this.state.isDarkMode ? 'dark' : 'light');
        
        const icon = document.querySelector('#btn-theme i');
        if (icon) icon.className = this.state.isDarkMode ? 'fas fa-sun' : 'fas fa-moon';
        
        if (this.renderer) this.renderer.setTheme(this.state.isDarkMode);
    }
    
    // ========================================================================
    // UTILITIES
    // ========================================================================
    
    showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        if (!container) return;
        
        const icons = {
            success: 'fa-check-circle',
            warning: 'fa-exclamation-triangle',
            error: 'fa-times-circle',
            info: 'fa-info-circle'
        };
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <i class="toast-icon fas ${icons[type] || icons.info}"></i>
            <span class="toast-message">${message}</span>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }
    
    // ========================================================================
    // MATCHING CALCULATOR
    // ========================================================================

    calculateMatching() {
        if (!this.data.smith) {
            this.showToast('Sem dados de impedância', 'error');
            return;
        }

        // Pega a impedância na frequência central
        const smith = this.data.smith;
        const centerIdx = Math.floor(smith.resistance.length / 2);
        
        const R = smith.resistance[centerIdx];
        const X = smith.reactance[centerIdx];
        const f = this.state.frequency;
        const Z0 = 50;
        const w = 2 * Math.PI * f;

        // Mostra modal
        const modal = document.getElementById('matching-overlay');
        modal.classList.remove('hidden');

        // Atualiza Info
        document.getElementById('match-z-load').textContent = `${R.toFixed(1)} ${X >= 0 ? '+' : ''}${X.toFixed(1)}j Ω`;
        document.getElementById('match-freq').textContent = `${(f/1e6).toFixed(1)} MHz`;

        // Cálculo L-Match (Topology: Series X, Shunt B)
        // Simplificação: Considerar Resistência pura primeiro? Não, usar fórmulas completas.
        // Referência: http://www.amanogawa.com/archive/docs/L-Match.pdf
        
        // Caso 1: R < Z0 (Boost) -> Topologia: Series L/C next to Load, Shunt L/C next to Source?
        // Standard approach:
        // Se R < Z0: Shunt Component at Load side, Series Component at Source side? No.
        // Let's use Q method.
        
        let Q = 0;
        let seriesX = 0;
        let shuntB = 0;
        let topology = '';

        // Definindo componentes
        let seriesComp = { type: '', val: 0, unit: '' };
        let shuntComp = { type: '', val: 0, unit: '' };

        try {
            if (R < Z0) {
                // Topologia: Elemento Série próximo à Carga (para cancelar X e transformar R?)
                // Não, R < Z0 pede step-up.
                // Topologia 1: L-Network com elemento SHUNT do lado do SOURCE (50 ohms) e SERIE do lado da CARGA (Zl)
                // Q = sqrt( (Z0/R) - 1 )
                // Xs = Q * R - X  (Series Reactance)
                // Bp = Q / Z0     (Shunt Susceptance)
                
                // Mas X load complica.
                // Vamos usar a abordagem analítica simples:
                // Z_in = jXs + 1 / (jBp + 1/Z0)  <-- Isso é Shunt no Source.
                // Queremos Z_in = Z_load* (conjugado)? Não, queremos Z_seen_by_source = 50.
                
                // Vamos simplificar para o usuário:
                // "Adicione Series L/C e Shunt L/C"
                
                // Solução Low-Pass (bloqueia harmônicos)
                
                // Virtual Resistance approach
                // Se R < 50:
                // Step-up. Shunt Xp at Source side. Series Xs at Load side.
                // Q = sqrt(50/R - 1)
                // Xs = Q*R - X_load
                // Xp = 50/Q
                
                const q = Math.sqrt((Z0/R) - 1);
                const Xs = q * R - X; // Reatância série necessária
                const Xp = Z0 / q;    // Reatância paralela (capacitiva ou indutiva)
                
                // Preferência Low Pass: Indutor Série, Capacitor Paralelo
                // Se Xs > 0 (Indutor), Se Xs < 0 (Capacitor)
                // Para Low Pass, geralmente queremos Series L, Shunt C.
                // Isso requer Xp ser capacitivo (negativo, mas Bp positivo?)
                // Xp aqui é reatância. Capacitor tem Xc = -1/wC.
                // Shunt C means Bp = wC. Zp = -j/wC.
                
                // Solução 1 (Low Pass-ish):
                // Series Element Xs
                // Shunt Element (at Source) Xp = - (Z0/Q) (Capacitor)
                
                // Series
                if (Xs > 0) {
                    seriesComp = { type: 'Indutor (Série)', val: Xs / w, unit: 'H' };
                } else {
                    seriesComp = { type: 'Capacitor (Série)', val: -1 / (w * Xs), unit: 'F' };
                }
                
                // Shunt (no lado da fonte)
                // Vamos forçar capacitor no shunt para low pass
                const Xp_cap = -Z0 / q;
                shuntComp = { type: 'Capacitor (Shunt @ Fonte)', val: -1 / (w * Xp_cap), unit: 'F' };
                
                topology = 'Shunt @ Fonte';

            } else {
                // R > Z0 (ou High Impedance Region)
                // Topologia: Shunt component at Load side, Series component at Source side.
                // Cálculo exato considerando carga complexa Z_load = R + jX
                
                const G_load = R / (R*R + X*X);
                const B_load = -X / (R*R + X*X);
                
                // Verificação de viabilidade (Real(Y_load) deve ser < 1/50 para esta topologia funcionar como step-down de impedância visto da fonte?)
                // Na verdade, visto da fonte, queremos ver 50.
                // A topologia Shunt-Series transforma impedâncias altas (na carga) para baixas (na fonte)?
                // Sim, Shunt reduz a resistência paralela equivalente.
                
                if (G_load > 1/Z0) {
                     throw new Error("Topologia inadequada para esta impedância (G_load > 1/50).");
                }
                
                // Solução para B_shunt
                // (B_shunt + B_load)^2 = G_load/Z0 - G_load^2
                const term = G_load/Z0 - G_load*G_load;
                if (term < 0) throw new Error("Impedância fora da região de casamento.");
                
                // Escolha do sinal para Low Pass (Series L, Shunt C)
                // Queremos Series L => X_series > 0
                // X_series = 50 * (B_total) / G_load
                // Então precisamos B_total > 0.
                
                const B_total = Math.sqrt(term); // Raiz positiva
                const B_shunt_val = B_total - B_load;
                
                const X_series_val = Z0 * B_total / G_load;
                
                // Definindo componentes
                // Shunt Element (B_shunt_val)
                if (B_shunt_val > 0) {
                    shuntComp = { type: 'Capacitor (Shunt @ Carga)', val: B_shunt_val / w, unit: 'F' };
                } else {
                    shuntComp = { type: 'Indutor (Shunt @ Carga)', val: -1 / (w * B_shunt_val), unit: 'H' };
                }
                
                // Series Element (X_series_val)
                if (X_series_val > 0) {
                    seriesComp = { type: 'Indutor (Série)', val: X_series_val / w, unit: 'H' };
                } else {
                    seriesComp = { type: 'Capacitor (Série)', val: -1 / (w * X_series_val), unit: 'F' };
                }
                
                topology = 'Shunt @ Carga, Série @ Fonte';
            }

            // Formatação
            const formatVal = (v, u) => {
                if (u === 'H') {
                    if (v < 1e-6) return (v * 1e9).toFixed(1) + ' nH';
                    return (v * 1e6).toFixed(1) + ' uH';
                } else {
                    if (v < 1e-9) return (v * 1e12).toFixed(1) + ' pF';
                    return (v * 1e9).toFixed(1) + ' nF';
                }
            };

            document.getElementById('comp-series').textContent = seriesComp.type;
            document.getElementById('match-val-series').textContent = formatVal(Math.abs(seriesComp.val), seriesComp.unit);
            
            document.getElementById('comp-shunt').textContent = shuntComp.type;
            document.getElementById('match-val-shunt').textContent = formatVal(Math.abs(shuntComp.val), shuntComp.unit);
            
        } catch (e) {
            console.error(e);
            document.getElementById('match-val-series').textContent = "Erro";
            document.getElementById('match-val-shunt').textContent = "Erro";
        }
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Initialize
const app = new AntennaSim();
